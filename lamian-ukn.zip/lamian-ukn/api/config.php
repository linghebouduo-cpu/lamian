// === 共用寄信：先試 SMTP，失敗退回 mail() ===
function sendMailSmart(string $to, string $toName, string $subject, string $htmlBody, string $altBody = ''): bool {
    // 先試 PHPMailer SMTP
    try {
        if (class_exists('\PHPMailer\PHPMailer\PHPMailer')) {
            $mail = new \PHPMailer\PHPMailer\PHPMailer(true);
            // <<< 換成你自己的 SMTP >>>
            $mail->isSMTP();
            $mail->Host       = 'smtp.gmail.com';
            $mail->SMTPAuth   = true;
            $mail->Username   = 's114jsys@gmail.com';
            $mail->Password   = 'jqcu bqpt oggt ojeh'; // App Password
            $mail->SMTPSecure = \PHPMailer\PHPMailer\PHPMailer::ENCRYPTION_SMTPS;
            $mail->Port       = 465;
            $mail->CharSet    = 'UTF-8';

            $mail->setFrom('s114jsys@gmail.com', 'OM 刨冰');
            $mail->addReplyTo('s114jsys@gmail.com', 'OM 刨冰');
            $mail->addAddress($to, $toName);

            $mail->isHTML(true);
            $mail->Subject = $subject;
            $mail->Body    = $htmlBody;
            $mail->AltBody = $altBody !== '' ? $altBody : strip_tags($htmlBody);

            $mail->send();
            return true;
        }
    } catch (\Throwable $e) {
        error_log('[sendMailSmart][SMTP] '.$e->getMessage());
        // 繼續嘗試 mail()
    }

    // 退回 PHP mail()
    try {
        $headers = "From: OM 刨冰 <s114jsys@gmail.com>\r\n".
                   "Reply-To: s114jsys@gmail.com\r\n".
                   "MIME-Version: 1.0\r\n".
                   "Content-Type: text/html; charset=UTF-8\r\n";
        $ok = @mail($to, '=?UTF-8?B?'.base64_encode($subject).'?=', $htmlBody, $headers);
        if (!$ok) error_log('[sendMailSmart][mail()] failed to '.$to);
        return $ok;
    } catch (\Throwable $e) {
        error_log('[sendMailSmart][mail()] '.$e->getMessage());
        return false;
    }
}
