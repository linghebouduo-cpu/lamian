<?php
// /lamian-ukn/api/config.php
// 不要在這裡送 Content-Type，避免整站被當 JSON

// === DB 連線設定 ===
const DB_HOST = '127.0.0.1';
const DB_NAME = 'lamian';
const DB_USER = 'root';
const DB_PASS = '';

// === 員工表 與 打卡表 ===
const EMP_TABLE     = '員工基本資料';
const EMP_PK_COL    = 'id';
const EMP_NAME_COL  = 'name';
const EMP_CODE_COL  = 'id';           // 打卡輸入代碼，預設用 id
const ATT_TABLE     = 'attendance';

// === 共用小工具 ===
function pdo(){
  static $pdo = null;
  if ($pdo) return $pdo;
  $dsn = 'mysql:host='.DB_HOST.';dbname='.DB_NAME.';charset=utf8mb4';
  $pdo = new PDO($dsn, DB_USER, DB_PASS, [
    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
  ]);
  return $pdo;
}

function ok($data){
  header('Content-Type: application/json; charset=utf-8');
  echo json_encode($data, JSON_UNESCAPED_UNICODE);
  exit;
}

function err($msg,$code=500,$ext=[]){
  header('Content-Type: application/json; charset=utf-8');
  http_response_code($code);
  echo json_encode(['error'=>$msg]+$ext, JSON_UNESCAPED_UNICODE);
  exit;
}

function g($k,$d=null){ return isset($_GET[$k]) ? trim($_GET[$k]) : $d; }
