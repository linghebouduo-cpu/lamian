<?php
// /lamian-ukn/api/me.php
require_once __DIR__ . '/auth_core.php';
require_once __DIR__ . '/config.php';

$uid = require_login_core();

$pdo = pdo();
try {
  $sql = "SELECT id, name, Telephone, Position, email, address, 
                 emergency_contact, emergency_phone, memo, avatar_url
          FROM `員工基本資料`
          WHERE id = ?";
  $st = $pdo->prepare($sql);
  $st->execute([$uid]);
  $emp = $st->fetch();

  if (!$emp) {
    http_response_code(404);
    echo json_encode(['error' => '找不到員工資料']);
    exit;
  }

  echo json_encode($emp, JSON_UNESCAPED_UNICODE);

} catch (Throwable $e) {
  http_response_code(500);
  echo json_encode(['error' => $e->getMessage()]);
}
