<?php
declare(strict_types=1);
require_once __DIR__ . '/db_auth.php'; // 連接包含 password 表的資料庫 (需要 pdo_auth())
require_once __DIR__ . '/config.php';  // 引入 PDO(lamian)、常數和 send_email 函數

header('Content-Type: application/json; charset=utf-8');

// 統一錯誤處理
set_exception_handler(function(Throwable $e){
  error_log("Password Request Error: " . $e->getMessage() . "\n" . $e->getTraceAsString());
  err('伺服器處理時發生錯誤', 500);
});

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
  err('請求方法錯誤', 405);
}

$in    = json_decode(file_get_contents('php://input') ?: '[]', true) ?: [];
$email = trim($in['email'] ?? '');
if ($email === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
  err('請輸入有效的 Email 地址');
}

$employee_name = '使用者'; // 預設名稱
$employee_id = null;
$known = false;

// 1. 檢查 Email 是否存在於員工資料表，並取得姓名和 ID (使用 config.php 的 pdo())
try {
    $pdo_lamian = pdo(); // 連接到 lamian 資料庫
    // 同時取得 id 和 name
    $chk = $pdo_lamian->prepare("SELECT `".EMP_PK_COL."`, `".EMP_NAME_COL."` FROM `" . DB_NAME . "`.`" . EMP_TABLE . "` WHERE `email`=? LIMIT 1");
    $chk->execute([$email]);
    $employee = $chk->fetch();
    if ($employee !== false) {
        $known = true;
        $employee_name = $employee[EMP_NAME_COL] ?? '使用者';
        $employee_id = $employee[EMP_PK_COL] ?? null; // 獲取員工 ID
    }
} catch (PDOException $e) {
    error_log("Email check failed for {$email}: " . $e->getMessage());
    $known = false;
}

$code  = str_pad((string)random_int(0, 999999), 6, '0', STR_PAD_LEFT);
$token = bin2hex(random_bytes(32));
$mail_sent_successfully = false;

if ($known && $employee_id !== null) { // 確保 Email 存在且 ID 有取到
  try {
      $pdo_auth = pdo_auth(); // 連接到包含 password 表的資料庫

      // 作廢此 email 其他未使用的 request
      $stmt_invalidate = $pdo_auth->prepare("UPDATE `password` SET `used` = 1 WHERE `email` = ? AND `used` = 0");
      $stmt_invalidate->execute([$email]);

      // 插入新的重設請求記錄 (加入 user_id)
      // *** 請先確認 password 表有 user_id 欄位 (INT) ***
      $ins = $pdo_auth->prepare(
          "INSERT INTO `password` (`email`, `user_id`, `code`, `token`, `expires_at`, `created_at`)
           VALUES (?, ?, ?, ?, DATE_ADD(NOW(), INTERVAL ? MINUTE), NOW())"
      );
      // 注意: 這裡儲存了明文 code
      $ins->execute([$email, $employee_id, $code, $token, RESET_CODE_TTL_MIN]);

      // 準備 Email 內容
      $subject = '=?UTF-8?B?' . base64_encode('密碼重設驗證碼 - ' . MAIL_FROM_NAME) . '?='; // UTF-8 編碼主旨
      // 簡單的 HTML 郵件內容
      $html_body = "
      <p>您好 {$employee_name},</p>
      <p>您正在請求重設員工管理系統的密碼。</p>
      <p>您的驗證碼是： <strong style='font-size: 1.2em; color: #dc3545;'>{$code}</strong></p>
      <p>此驗證碼將在 <strong>" . RESET_CODE_TTL_MIN . " 分鐘</strong>後失效。</p>
      <p>如果您沒有請求重設密碼，請忽略此郵件。</p>
      <p>--<br>" . MAIL_FROM_NAME . "</p>";
      // 純文字版本
       $text_body = "您好 {$employee_name},\n\n您正在請求重設員工管理系統的密碼。\n\n您的驗證碼是：{$code}\n\n此驗證碼將在 " . RESET_CODE_TTL_MIN . " 分鐘後失效。\n如果您沒有請求重設密碼，請忽略此郵件。\n\n--\n" . MAIL_FROM_NAME;


      // 使用 send_email 函數寄送
      $mail_sent_successfully = send_email($email, $employee_name, $subject, $html_body, $text_body);

      if (!$mail_sent_successfully) {
          error_log("Failed to send password reset email to {$email} using PHPMailer.");
      }
  } catch (PDOException $e) {
      error_log("DB error during password request for {$email}: " . $e->getMessage());
      // 即使 DB 錯誤，也不告訴前端
  }
}

// 無論如何都回傳一樣的成功訊息
ok(['ok'=>true, 'message'=>'如果您的 Email 地址存在於我們的系統中，您將會收到一封包含驗證碼的郵件。']);
?>