<?php
// /lamian-ukn/api/auth_core.php
declare(strict_types=1);

// 確保 session cookie 作用在整個站台（不是只在 /api 底下）
ini_set('session.cookie_path', '/');

if (session_status() !== PHP_SESSION_ACTIVE) {
  session_start();
}

// === 連線設定（沿用你的 config.php）===
require_once __DIR__ . '/config.php';

// 你原本的 pdo()/ok()/err() 可直接沿用 config.php 的；如需這裡也用到可再引入
function pdo_core() {
  return pdo(); // 直接用你 config.php 的 pdo()
}

/**
 * 取目前登入者 uid，未登入就回 401
 * 回傳 int uid
 */
function require_login_core(): int {
  if (empty($_SESSION['uid']) && empty($_SESSION['account'])) {
    http_response_code(401);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(['error' => 'UNAUTHORIZED'], JSON_UNESCAPED_UNICODE);
    exit;
  }
  return (int)($_SESSION['uid'] ?? 0);
}
