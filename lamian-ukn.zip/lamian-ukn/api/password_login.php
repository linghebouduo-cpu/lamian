<?php
// /lamian-ukn/api/password_login.php
declare(strict_types=1);
header('Content-Type: application/json; charset=utf-8');

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/auth_core.php';

try {
  $in = json_decode(file_get_contents('php://input'), true) ?: [];
  $account  = trim((string)($in['account']  ?? ''));
  $password = (string)($in['password'] ?? '');

  if ($account === '' || $password === '') {
    json_err('缺少帳號或密碼', 400);
  }

  $pdo = pdo();

  // 你說「帳號用 ID_card」，但之前也用過 account，兩個都試。
  $st = $pdo->prepare("
    SELECT id, name, account, ID_card, password_hash, email
    FROM `".EMP_TABLE."`
    WHERE ID_card = ? OR account = ?
    LIMIT 1
  ");
  $st->execute([$account, $account]);
  $u = $st->fetch();

  if (!$u) {
    json_err('帳號或密碼錯誤', 401);
  }

  $hash = (string)($u['password_hash'] ?? '');
  $ok = false;
  if ($hash !== '') {
    $ok = password_verify($password, $hash);
  }
  // 如果資料庫目前是明碼（不建議），容錯：
  if (!$ok && $password === $hash) $ok = true;

  if (!$ok) {
    json_err('帳號或密碼錯誤', 401);
  }

  // 設定登入會話
  login_set_user((int)$u['id']);

  json_ok([
    'ok'   => true,
    'user' => [
      'id'      => (int)$u['id'],
      'name'    => $u['name'],
      'account' => $u['account'],
      'ID_card' => $u['ID_card'],
      'email'   => $u['email'],
    ]
  ]);
} catch (Throwable $e) {
  json_err('SERVER_ERROR', 500, ['detail'=>$e->getMessage()]);
}
