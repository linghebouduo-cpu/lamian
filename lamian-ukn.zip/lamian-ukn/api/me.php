<?php
// /lamian-ukn/api/me.php
declare(strict_types=1);
header('Content-Type: application/json; charset=utf-8');

require_once __DIR__ . '/auth_core.php';
require_once __DIR__ . '/config.php';

$uid = require_login_core();

try {
    $pdo = pdo();
    $sql = "SELECT
              id,
              account,
              name,
              birth_date,
              role,
              Position,
              base_salary,
              hourly_rate,
              Telephone,
              address,
              ID_card,
              email,
              avatar_url
            FROM `員工基本資料`
            WHERE id = ?";
    $st = $pdo->prepare($sql);
    $st->execute([$uid]);
    $u = $st->fetch();

    if (!$u) {
        http_response_code(404);
        echo json_encode(['error' => 'NOT_FOUND'], JSON_UNESCAPED_UNICODE);
        exit;
    }

    // === 處理頭像網址 ===
    $avatar_url = null;
    if (!empty($u['avatar_url'])) {
        // 如果不是 http 開頭，就自動補上 localhost
        if (strpos($u['avatar_url'], 'http') === 0) {
            $avatar_url = $u['avatar_url'];
        } else {
            $avatar_url = 'http://localhost' . $u['avatar_url'];
        }
    } else {
        // 沒有頭像就給預設圖
        $avatar_url = 'https://i.pravatar.cc/240?img=12';
    }

    // === 組合輸出 ===
    echo json_encode([
        'id'          => (int)$u['id'],
        'username'    => $u['account'],
        'name'        => $u['name'],
        'birth_date'  => $u['birth_date'],
        'role'        => $u['role'],
        'Position'    => $u['Position'],
        'base_salary' => $u['base_salary'],
        'hourly_rate' => $u['hourly_rate'],
        'Telephone'   => $u['Telephone'],
        'address'     => $u['address'],
        'ID_card'     => $u['ID_card'],
        'email'       => $u['email'],
        'avatar_url'  => $avatar_url
    ], JSON_UNESCAPED_UNICODE);

} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['error' => 'Database Error: ' . $e->getMessage()], JSON_UNESCAPED_UNICODE);
    exit;
}
