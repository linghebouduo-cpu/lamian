<?php
// api/config.php
$DB_HOST = 'localhost';
$DB_NAME = 'lamian_member';  // 例如 lamian
$DB_USER = 'lamian04';
$DB_PASS = 'Aa110534104';

// 同一台主機建議維持 /api，若放子資料夾/他網域，自行更改
$API_BASE_URL = '/api';
