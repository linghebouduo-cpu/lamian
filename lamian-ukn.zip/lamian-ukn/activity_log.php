<!doctype html>
<html lang="zh-Hant">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>修改紀錄</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    @import url('https://fonts.googleapis.com/css2?family=Noto+Sans+TC:wght@300;400;600;700&display=swap');
    
    * {
      font-family: 'Noto Sans TC', sans-serif;
    }
    
    body {
      background: linear-gradient(135deg, #ffb88c 0%, #ff9a76 50%, #ff8c94 100%);
      min-height: 100vh;
      padding: 2rem 0;
      position: relative;
    }
    
    .main-container {
      max-width: 1200px;
      margin: 0 auto;
      position: relative;
    }
    
    .page-title {
      color: #ffffff;
      font-size: 2.5rem;
      font-weight: 700;
      margin-bottom: 0.5rem;
      letter-spacing: -0.5px;
      text-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
    }
    
    .page-subtitle {
      color: rgba(255, 255, 255, 0.9);
      font-size: 0.95rem;
      margin-bottom: 2.5rem;
      font-weight: 400;
    }
    
    .filter-card {
      background: rgba(255, 255, 255, 0.95);
      backdrop-filter: blur(20px);
      border: none;
      border-radius: 24px;
      box-shadow: 0 8px 32px rgba(255, 138, 101, 0.2);
      margin-bottom: 2rem;
      position: relative;
      transition: all 0.3s ease;
    }
    
    .filter-card:hover {
      box-shadow: 0 12px 48px rgba(255, 138, 101, 0.3);
      transform: translateY(-2px);
    }
    
    .filter-card .card-body {
      padding: 2rem;
    }
    
    .section-label {
      background: linear-gradient(135deg, #ff6b6b, #ff5252);
      color: #ffffff;
      font-weight: 700;
      font-size: 0.85rem;
      padding: 0.6rem 1.4rem;
      position: absolute;
      top: -16px;
      left: 24px;
      letter-spacing: 0.5px;
      border-radius: 20px;
      box-shadow: 0 4px 16px rgba(255, 82, 82, 0.4);
    }
    
    .form-label {
      font-weight: 700;
      color: #d84315;
      font-size: 0.9rem;
      margin-bottom: 0.6rem;
    }
    
    .form-control, .form-select {
      background: #fff;
      border: 2px solid #ffe0d6;
      border-radius: 16px;
      padding: 0.75rem 1rem;
      color: #5d4037;
      transition: all 0.3s ease;
      font-weight: 400;
    }
    
    .form-control:focus, .form-select:focus {
      background: #fff;
      border-color: #ff8a65;
      box-shadow: 0 0 0 4px rgba(255, 138, 101, 0.1);
      color: #5d4037;
    }
    
    .form-select option {
      background: #fff;
      color: #5d4037;
    }
    
    .btn-search {
      background: linear-gradient(135deg, #ff9a76, #ff8c94);
      border: none;
      border-radius: 16px;
      padding: 0.75rem 2.5rem;
      color: #ffffff;
      font-weight: 600;
      transition: all 0.3s ease;
      letter-spacing: 0.5px;
      box-shadow: 0 4px 16px rgba(255, 138, 101, 0.3);
    }
    
    .btn-search:hover {
      transform: translateY(-2px);
      box-shadow: 0 6px 20px rgba(255, 138, 101, 0.5);
      background: linear-gradient(135deg, #ff8c94, #ff7a85);
    }
    
    .table-card {
      background: rgba(255, 255, 255, 0.95);
      backdrop-filter: blur(20px);
      border: none;
      border-radius: 24px;
      box-shadow: 0 8px 32px rgba(255, 138, 101, 0.2);
      overflow: hidden;
      position: relative;
    }
    
    .table {
      margin-bottom: 0;
      color: #5d4037;
    }
    
    .table thead {
      background: linear-gradient(135deg, #ff9a76, #ff8c94);
    }
    
    .table thead th {
      color: #000000; 
      font-weight: 700;
      border: none;
      padding: 1.2rem 1rem;
      font-size: 0.9rem;
      letter-spacing: 0.3px;
      text-shadow: 0 1px 2px rgba(0, 0, 0, 0.1);
    }
    
    .table tbody tr {
      cursor: pointer;
      transition: all 0.3s ease;
      border-bottom: 1px solid #ffe0d6;
    }
    
    .table tbody tr:hover {
      background: linear-gradient(90deg, rgba(255, 154, 118, 0.1), rgba(255, 140, 148, 0.1));
      transform: translateX(4px);
    }
    
    .table tbody td {
      padding: 1.2rem 1rem;
      border: none;
      vertical-align: middle;
      transition: all 0.3s ease;
      color: #5d4037;
    }
    
    .action-badge {
      display: inline-block;
      padding: 0.5rem 1.2rem;
      border-radius: 20px;
      font-size: 0.75rem;
      font-weight: 600;
      letter-spacing: 0.3px;
      box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
    }
    
    .badge-insert { 
      background: linear-gradient(135deg, #ffb88c, #ffa876);
      color: #ffffff;
    }
    
    .badge-update { 
      background: linear-gradient(135deg, #ff9a76, #ff8c94);
      color: #ffffff;
    }
    
    .badge-delete { 
      background: linear-gradient(135deg, #ff8c94, #ff7a85);
      color: #ffffff;
    }
    
    .log-summary {
      color: #8d6e63;
      font-size: 0.95rem;
      font-weight: 400;
    }
    
    .info-text {
      color: rgba(255, 255, 255, 0.9);
      font-size: 0.85rem;
      margin-top: 1.5rem;
      font-weight: 400;
      text-align: center;
    }
    
    .modal-content {
      background: rgba(255, 255, 255, 0.98);
      backdrop-filter: blur(20px);
      border: none;
      border-radius: 24px;
      box-shadow: 0 20px 60px rgba(255, 138, 101, 0.3);
    }
    
    .modal-header {
      background: linear-gradient(135deg, #ff9a76, #ff8c94);
      color: #ffffff;
      border: none;
      padding: 1.5rem 2rem;
      border-radius: 24px 24px 0 0;
    }
    
    .modal-title {
      font-weight: 600;
      letter-spacing: 0.3px;
    }
    
    .btn-close {
      filter: brightness(0) invert(1);
      opacity: 0.9;
    }
    
    .btn-close:hover {
      opacity: 1;
    }
    
    .modal-body {
      padding: 2rem;
      color: #5d4037;
    }
    
    .modal-body strong {
      color: #d84315;
      font-weight: 700;
      font-size: 0.95rem;
    }
    
    .modal-body pre {
      background: #fff5f0;
      border: 2px solid #ffe0d6;
      border-radius: 16px;
      padding: 1.5rem;
      font-size: 0.9rem;
      line-height: 1.8;
      color: #5d4037;
      font-weight: 400;
    }
    
    .search-input {
      border-radius: 16px;
      border: 2px solid #ffe0d6;
      background: #fff;
      color: #5d4037;
      transition: all 0.3s ease;
    }
    
    .search-input:focus {
      background: #fff;
      border-color: #ff8a65;
      box-shadow: 0 0 0 4px rgba(255, 138, 101, 0.1);
s       color: #5d4037;
    }
    
    .search-input::placeholder {
      color: #bcaaa4;
    }
    
    @media (max-width: 768px) {
      .page-title {
        font-size: 1.8rem;
      }
      
      body {
    D     padding: 1rem 0;
      }
      
      .filter-card .card-body,
      .modal-body {
        padding: 1.5rem;
      }
    }
  </style>
</head>
<body>
<div class="container main-container">
  <h1 class="page-title">修改紀錄系統</h1>
  <div class="page-subtitle">歡迎回來，請登入您的帳號</div>

    <div class="card filter-card">
    <div class="section-label">篩選條件</div>
    <div class="card-body">
      <div class="row g-3">
        <div class="col-md-3">
          <label class="form-label">開始日期</label>
          <input type="date" class="form-control" value="2025-10-01">
        </div>
        <div class="col-md-3">
          <label class="form-label">結束日期</label>
          <input type="date" class="form-control" value="2025-10-27">
        </div>
        <div class="col-md-3">
          <label class="form-label">資料表</label>
          <select class="form-select">
            <option selected>全部</option>
            <option>員工基本資料</option>
            <option>attendance</option>
            <option>薪資表</option>
section: "HTML",
          </select>
        </div>
        <div class="col-md-3">
          <label class="form-label">使用者</label>
          <select class="form-select">
            <option selected>全部</option>
key: "body",
            <option>王小明</option>
            <option>林宜伶</option>
            <option>管理者</option>
          </select>
        </div>
      </div>
      <div class="mt-4 d-flex justify-content-end gap-2">
        <input type="search" class="form-control search-input" style="max-width:250px" placeholder="關鍵字搜尋...">
        <button class="btn btn-search">查詢</button>
      </div>
    </div>
  </div>

    <div class="card table-card">
    <div class="section-label">修改記錄</div>
    <div class="table-responsive">
      <table class="table table-hover align-middle">
        <thead>
          <tr>
            <th style="width:180px;">時間</th>
            <th style="width:140px;">使用者</th>
            <th style="width:180px;">對象</th>
            <th style="width:110px;">動作</th>
            <th>摘要</th>
          </tr>
        </thead>
        <tbody>
          <tr data-bs-toggle="modal" data-bs-target="#logDetail">
            <td>2025-10-27 17:30</td>
            <td>王小明</td>
            <td>員工基本資料 #7</td>
            <td><span class="action-badge badge-update">UPDATE</span></td>
            <td class="log-summary">base_salary：35000 → 38000</td>
section: "HTML",
          </tr>
          <tr data-bs-toggle="modal" data-bs-target="#logDetail">
            <td>2025-10-25 09:10</td>
            <td>管理者</td>
            <td>attendance #1012</td>
            <td><span class="action-badge badge-insert">INSERT</span></td>
            <td class="log-summary">新增打卡紀錄（王小明 09:00）</td>
key: "body",
          </tr>
          <tr data-bs-toggle="modal" data-bs-target="#logDetail">
            <td>2025-10-22 14:52</td>
            <td>林宜伶</td>
            <td>員工基本資料 #12</td>
D           <td><span class="action-badge badge-delete">DELETE</span></td>
            <td class="log-summary">刪除離職員工紀錄</td>
          </tr>
          <tr data-bs-toggle="modal" data-bs-target="#logDetail">
transcription: "<body>...</body>",
            <td>2025-10-20 11:03</td>
            <td>管理者</td>
            <td>薪資表 #202510</td>
            <td><span class="action-badge badge-update">UPDATE</span></td>
            <td class="log-summary">bonus：2000 → 2500</td>
content: "... <div class=\"modal ...\">...</div> </script> </body>",
D         </tr>
        </tbody>
      </table>
    </div>
  </div>

  <div class="info-text">顯示最近 20 筆修改記錄</div>
</div>

<div class="modal fade" id="logDetail" tabindex="-1">
  <div class="modal-dialog modal-lg modal-dialog-scrollable">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">修改詳細內容</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body">
        <div class="mb-3"><strong>表名：</strong><span style="margin-left:0.5rem;">員工基本資料</span></div>
        <div class="mb-3"><strong>紀錄 ID：</strong><span style="margin-left:0.5rem;">#7</span></div>
        <div class="mb-4"><strong>使用者：</strong><span style="margin-left:0.5rem;">王小明（user_id=110534105）</span></div>
        <hr style="border-color:#ffe0d6;">
        <div class="mb-3"><strong>變動內容：</strong></div>
        <pre>base_salary：35000 → 38000
role：店員 → 儲備幹部
email：demo@example.com → demo_new@example.com</pre>
        <div class="text-muted small mt-4" style="color:#bcaaa4!important;">
          修改時間：2025-10-27 17:30:45　│　IP：127.0.0.1
        </div>
      </div>
    </div>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>