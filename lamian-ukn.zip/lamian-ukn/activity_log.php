<?php
// (可選) 引入登入保護
// require_once __DIR__ . '/api/auth_guard.php';
$API_BASE_URL = '/lamian-ukn/api'; // 您的 API 路徑
?>
<!DOCTYPE html>
<html lang="zh-Hant">
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <title>操作記錄 - 員工管理系統</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" />
    <link href="css/styles.css" rel="stylesheet" />
    <script src="https://use.fontawesome.com/releases/v6.3.0/js/all.js" crossorigin="anonymous"></script>

    <style>
        /* 複製您其他頁面的 :root 和基本樣式 */
        :root{
          --primary-gradient: linear-gradient(135deg, #fbb97ce4 0%, #ff0000cb 100%);
          --secondary-gradient: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);
          --success-gradient: linear-gradient(135deg, #4facfe 0%, #54bcc1 100%);
          --warning-gradient: linear-gradient(135deg, #fbb97ce4 0%, #ff00006a 100%);
          --dark-bg: linear-gradient(135deg, #fbb97ce4 0%, #ff00006a 100%);
          --card-shadow: 0 15px 35px rgba(0,0,0,.1);
          --border-radius: 20px;
          --transition: all .3s cubic-bezier(.4,0,.2,1);
        }
        *{ transition: var(--transition); }
        body{ background:#fff; font-family:'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; min-height:100vh; }
        .sb-topnav{ background: var(--dark-bg) !important; border:none; box-shadow:var(--card-shadow); backdrop-filter: blur(10px); }
        .navbar-brand{ font-weight:700; font-size:1.5rem; background: linear-gradient(45deg,#ffffff,#ffffff); -webkit-background-clip:text; background-clip:text; color:transparent; -webkit-text-fill-color:transparent; }
        .sb-sidenav{ background: linear-gradient(180deg,#fbb97ce4 0%, #ff00006a 100%) !important; box-shadow: var(--card-shadow); backdrop-filter: blur(10px); }
        .sb-sidenav-menu-heading{ color: rgba(255,255,255,.7) !important; font-weight:600; font-size:.85rem; text-transform:uppercase; letter-spacing:1px; padding:20px 15px 10px 15px !important; margin-top:15px; }
        .sb-sidenav .nav-link{ border-radius:15px; margin:5px 15px; padding:12px 15px; position:relative; overflow:hidden; color:rgba(255,255,255,.9)!important; font-weight:500; backdrop-filter: blur(10px); }
        .sb-sidenav .nav-link:hover{ background:rgba(255,255,255,.15)!important; transform:translateX(8px); box-shadow:0 8px 25px rgba(0,0,0,.2); color:#fff!important; }
        .sb-sidenav .nav-link.active{ background:rgba(255,255,255,.2)!important; color:#fff!important; font-weight:600; box-shadow:0 8px 25px rgba(0,0,0,.15); }
        .sb-sidenav .nav-link::before{ content:''; position:absolute; left:0; top:0; height:100%; width:4px; background: linear-gradient(45deg,#ffffff,#ffffff); transform:scaleY(0); border-radius:0 10px 10px 0; }
        .sb-sidenav .nav-link:hover::before, .sb-sidenav .nav-link.active::before{ transform: scaleY(1); }
        .sb-sidenav-footer{ background: rgba(255,255,255,.1) !important; color:#fff !important; border-top:1px solid rgba(255,255,255,.2); padding:20px 15px; margin-top:20px; }
        .container-fluid{ padding:30px !important; }
        h1{ background: var(--primary-gradient); -webkit-background-clip:text; background-clip:text; color:transparent; -webkit-text-fill-color:transparent; font-weight:700; font-size:2.2rem; margin-bottom:30px; }
        .breadcrumb{ background: rgba(255,255,255,.8); border-radius: var(--border-radius); padding: 12px 16px; box-shadow: var(--card-shadow); backdrop-filter: blur(10px); }
        .card{ border:none; border-radius: var(--border-radius); box-shadow: var(--card-shadow); background:#fff; overflow:hidden; }
        .card-header{ background: linear-gradient(135deg, rgba(255,255,255,.9), rgba(255,255,255,.7)); font-weight:600; }
        .table thead th{ background: var(--primary-gradient); color:#000; border:none; font-weight:600; padding:12px; }
        .table tbody td{ padding:10px 12px; vertical-align:middle; border-color:rgba(0,0,0,.05); font-size: 0.9rem; } /* Smaller font size for log */
        .table-hover tbody tr:hover{ background:rgba(227,23,111,.05); }
        .btn-primary{ background: var(--primary-gradient); border:none; border-radius:25px; }
        .btn-primary:hover{ transform:scale(1.05); box-shadow:0 10px 25px rgba(209,209,209,.9); }
        .details-cell { max-width: 300px; white-space: normal; word-break: break-word; } /* Allow details to wrap */
        .ip-cell { color: #6c757d; font-size: 0.8em; } /* Style IP address */
    </style>
</head>
<body class="sb-nav-fixed">
    <nav class="sb-topnav navbar navbar-expand navbar-dark bg-dark">
        <a class="navbar-brand ps-3" href="index.php">員工管理系統</a>
        <button class="btn btn-link btn-sm order-1 order-lg-0 me-4 me-lg-0" id="sidebarToggle"><i class="fas fa-bars"></i></button>
        <ul class="navbar-nav ms-auto ms-md-0 me-3 me-lg-4">
            <li class="nav-item dropdown">
                 <a class="nav-link dropdown-toggle" id="navbarDropdown" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                    <img class="user-avatar rounded-circle me-1" src="https://i.pravatar.cc/40?u=placeholder" width="28" height="28" alt="User Avatar" style="vertical-align: middle;">
                    <span id="navUserName">載入中...</span>
                </a>
                <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
                    <li><a class="dropdown-item" href="帳號設置.php">帳號設置</a></li>
                    <li><hr class="dropdown-divider" /></li>
                    <li><a class="dropdown-item" href="logout.php">登出</a></li>
                </ul>
            </li>
        </ul>
    </nav>

    <div id="layoutSidenav">
        <div id="layoutSidenav_nav">
            <nav class="sb-sidenav accordion sb-sidenav-dark" id="sidenavAccordion">
                <div class="sb-sidenav-menu">
                    <div class="nav">
                        <div class="sb-sidenav-menu-heading">Core</div>
                        <a class="nav-link" href="index.php"><div class="sb-nav-link-icon"><i class="fas fa-tachometer-alt"></i></div>首頁</a>
                         <div class="sb-sidenav-menu-heading">Pages</div>
                        <a class="nav-link collapsed" href="#" data-bs-toggle="collapse" data-bs-target="#collapseLayouts"><div class="sb-nav-link-icon"><i class="fas fa-columns"></i></div>人事管理<div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div></a>
                        <div class="collapse" id="collapseLayouts" data-bs-parent="#sidenavAccordion">
                          <nav class="sb-sidenav-menu-nested nav">
                            <a class="nav-link" href="員工資料表.php">員工資料表</a>
                            <a class="nav-link" href="班表管理.php">班表管理</a>
                            <a class="nav-link" href="日報表記錄.php">日報表記錄</a>
                            <a class="nav-link" href="假別管理.php">假別管理</a>
                            <a class="nav-link" href="打卡管理.php">打卡管理</a>
                            <a class="nav-link" href="薪資管理.php">薪資管理</a>
                          </nav>
                        </div>
                        <a class="nav-link collapsed" href="#" data-bs-toggle="collapse" data-bs-target="#collapseOperation"><div class="sb-nav-link-icon"><i class="fas fa-chart-line"></i></div>營運管理<div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div></a>
                         <div class="collapse" id="collapseOperation" data-bs-parent="#sidenavAccordion"><nav class="sb-sidenav-menu-nested nav accordion" id="sidenavAccordionOperation"><a class="nav-link collapsed" href="#" data-bs-toggle="collapse" data-bs-target="#operationCollapseInventory"><div class="sb-nav-link-icon"><i class="fas fa-boxes"></i></div>庫存管理<div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div></a><div class="collapse" id="operationCollapseInventory" data-bs-parent="#sidenavAccordionOperation"><nav class="sb-sidenav-menu-nested nav"><a class="nav-link" href="庫存查詢.php">庫存查詢</a><a class="nav-link" href="庫存調整.php">庫存調整</a></nav></div><a class="nav-link" href="日報表.html"><div class="sb-nav-link-icon"><i class="fas fa-file-invoice-dollar"></i></div>日報表</a><a class="nav-link" href="薪資記錄.html"><div class="sb-nav-link-icon"><i class="fas fa-wallet"></i></div>薪資記錄</a><a class="nav-link" href="班表.html"><div class="sb-nav-link-icon"><i class="fas fa-calendar-days"></i></div>班表</a></nav></div>
                         <a class="nav-link" href="請假申請.html"><div class="sb-nav-link-icon"><i class="fas fa-calendar-alt"></i></div>請假申請</a>
                         <a class="nav-link" href="activity_log.php" class="nav-link active"><div class="sb-nav-link-icon"><i class="fas fa-history"></i></div>操作記錄</a> </div>
                </div>
                <div class="sb-sidenav-footer">
                    <div class="small">Logged in as:</div>
                    <span id="loggedAs">載入中...</span>
                </div>
            </nav>
        </div>

        <div id="layoutSidenav_content">
            <main>
                <div class="container-fluid px-4">
                    <div class="d-flex justify-content-between align-items-center mb-3">
                        <h1>操作記錄</h1>
                        <div class="text-muted"><i class="fas fa-calendar-alt me-2"></i><span id="currentDate"></span></div>
                    </div>

                    <ol class="breadcrumb mb-4">
                        <li class="breadcrumb-item"><a href="index.php" class="text-decoration-none">首頁</a></li>
                        <li class="breadcrumb-item active">操作記錄</li>
                    </ol>

                    <div class="card mb-4">
                        <div class="card-body">
                            <div class="row g-3 align-items-end">
                                <div class="col-lg-3 col-md-6">
                                    <label class="form-label">開始日期</label>
                                    <input type="date" class="form-control form-control-sm" id="filterStartDate">
                                </div>
                                <div class="col-lg-3 col-md-6">
                                    <label class="form-label">結束日期</label>
                                    <input type="date" class="form-control form-control-sm" id="filterEndDate">
                                </div>
                                <div class="col-lg-2 col-md-4">
                                    <label class="form-label">操作人員</label>
                                    <select class="form-select form-select-sm" id="filterUser">
                                        <option value="">全部</option>
                                        </select>
                                </div>
                                <div class="col-lg-2 col-md-4">
                                    <label class="form-label">操作類型</label>
                                    <select class="form-select form-select-sm" id="filterAction">
                                        <option value="">全部</option>
                                        <option value="CREATE">新增</option>
                                        <option value="UPDATE">修改</option>
                                        <option value="DELETE">刪除</option>
                                        <option value="APPROVE">核准</option>
                                        <option value="REJECT">駁回</option>
                                        <option value="LOGIN_SUCCESS">登入成功</option>
                                        <option value="LOGIN_FAIL">登入失敗</option>
                                        <option value="PASSWORD_RESET_SUCCESS">密碼重設</option>
                                        <option value="INVENTORY_ADJUST">庫存調整</option>
                                        </select>
                                </div>
                                <div class="col-lg-2 col-md-4 d-flex gap-2">
                                    <button class="btn btn-primary btn-sm flex-grow-1" id="btnFilter"><i class="fas fa-search"></i> 查詢</button>
                                    <button class="btn btn-outline-secondary btn-sm" id="btnClearFilter" title="清除條件"><i class="fas fa-eraser"></i></button>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="card mb-4">
                        <div class="card-header"><i class="fas fa-history me-1"></i>最近操作記錄</div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-bordered table-hover align-middle">
                                    <thead>
                                        <tr>
                                            <th style="width: 150px;">時間</th>
                                            <th style="width: 100px;">操作人員</th>
                                            <th style="width: 120px;">操作類型</th>
                                            <th style="width: 150px;">目標</th>
                                            <th>詳細內容</th>
                                            <th style="width: 120px;">IP 位址</th>
                                        </tr>
                                    </thead>
                                    <tbody id="logTableBody">
                                        <tr><td colspan="6" class="text-center text-muted py-5">載入中...</td></tr>
                                    </tbody>
                                </table>
                            </div>
                            </div>
                    </div>

                </div>
            </main>

            <footer class="py-4 bg-light mt-auto">
                <div class="container-fluid px-4"><div class="d-flex align-items-center justify-content-between small"><div class="text-muted">Copyright &copy; Xxing0625</div><div><a href="#">Privacy Policy</a> &middot; <a href="#">Terms &amp; Conditions</a></div></div></div>
            </footer>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
    <script src="js/scripts.js"></script> <script>
        const API_LOGS = <?php echo json_encode($API_BASE_URL . '/activity_log_list.php', JSON_UNESCAPED_SLASHES); ?>; // 假設的 API 端點
        const API_USERS = <?php echo json_encode($API_BASE_URL . '/employee_list.php', JSON_UNESCAPED_SLASHES); ?>; // 假設的 API 端點
        const API_ME    = <?php echo json_encode($API_BASE_URL . '/me.php', JSON_UNESCAPED_SLASHES); ?>;

        const el = id => document.getElementById(id);
        const escapeHtml = s => String(s ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));

        // 載入登入者資訊 (Navbar & Sidebar Footer)
        async function loadLoggedInUser() {
            // ... (複製 index.php 中的 loadLoggedInUser 函數內容) ...
             try {
                const r = await fetch(API_ME, { credentials: 'include' });
                if (!r.ok) throw new Error('Cannot fetch user info: HTTP ' + r.status);
                const userData = await r.json();
                const userName = userData.name || '使用者';
                const loggedAsSpan = el('loggedAs'); if (loggedAsSpan) loggedAsSpan.textContent = userName;
                const navUserNameSpan = el('navUserName'); if (navUserNameSpan && userData.name) navUserNameSpan.textContent = userData.name;
                const navUserAvatar = document.querySelector('.navbar .user-avatar');
                if (navUserAvatar && userData.avatar_url) {
                    const url = userData.avatar_url + (userData.avatar_url.includes('?')?'&':'?') + 'v=' + Date.now();
                    navUserAvatar.src = url;
                }
            } catch (e) {
                console.error("Failed to load user name:", e);
                const loggedAsSpan = el('loggedAs'); if (loggedAsSpan) loggedAsSpan.textContent = '無法載入';
                const navUserNameSpan = el('navUserName'); if (navUserNameSpan) navUserNameSpan.textContent = '錯誤';
            }
        }


        // 範例資料 (替代 API 回應)
        const sampleLogs = [
            { log_id: 105, user_id: 1005, user_name: 'ILING LIN', timestamp: '2025-10-27 15:30:05', action_type: 'UPDATE', target_table: '員工基本資料', target_id: '1005', details: '更新個人資料: email, address', ip_address: '192.168.1.10' },
            { log_id: 104, user_id: 110534104, user_name: '葉芃孝', timestamp: '2025-10-27 14:15:22', action_type: 'CREATE', target_table: 'attendance', target_id: '49', details: '上班打卡', ip_address: '114.32.110.5' },
            { log_id: 103, user_id: 1002, user_name: '胡瓜', timestamp: '2025-10-26 18:05:11', action_type: 'LOGIN_SUCCESS', target_table: null, target_id: null, details: '登入成功', ip_address: '1.168.1.123' },
            { log_id: 102, user_id: null, user_name: '系統', timestamp: '2025-10-26 10:00:00', action_type: 'PASSWORD_RESET_SUCCESS', target_table: '員工基本資料', target_id: '1006', details: 'Email: xxx@xxx.com 密碼重設成功', ip_address: null },
            { log_id: 101, user_id: 1006, user_name: 'aaa', timestamp: '2025-10-25 09:12:35', action_type: 'INVENTORY_ADJUST', target_table: '庫存管理', target_id: '39', details: '庫存調整: 鱸魚 = 354 (修正)', ip_address: '192.168.1.15' }
        ];

        const sampleUsers = [
            { id: 1002, name: '胡瓜' },
            { id: 1005, name: 'ILING LIN' },
            { id: 1006, name: 'aaa' },
            { id: 110534104, name: '葉芃孝' }
        ];

        // 載入操作人員下拉選單 (使用範例資料)
        function loadUserFilter() {
            const select = el('filterUser');
            select.innerHTML = '<option value="">全部</option>'; // Reset
            sampleUsers.sort((a, b) => a.name.localeCompare(b.name, 'zh-Hant'));
            sampleUsers.forEach(user => {
                select.appendChild(new Option(`${user.name} (${user.id})`, String(user.id)));
            });
            // 之後連接 API:
            // try {
            //     const users = await fetchJSON(API_USERS);
            //     const select = el('filterUser');
            //     select.innerHTML = '<option value="">全部</option>';
            //     (users || []).forEach(u => select.appendChild(new Option(`${u.name} (${u.id})`, String(u.id))));
            // } catch (e) { console.error("無法載入使用者列表", e); }
        }

        // 渲染表格 (使用範例資料)
        function renderTable(logs) {
            const tbody = el('logTableBody');
            if (!logs || logs.length === 0) {
                tbody.innerHTML = '<tr><td colspan="6" class="text-center text-muted py-5">找不到符合條件的記錄</td></tr>';
                return;
            }
            tbody.innerHTML = logs.map(log => `
                <tr>
                    <td>${escapeHtml(log.timestamp)}</td>
                    <td>${escapeHtml(log.user_name || log.user_id || '系統')}</td>
                    <td>${escapeHtml(log.action_type)}</td>
                    <td>${escapeHtml(log.target_table ? `${log.target_table} #${log.target_id || ''}` : '-')}</td>
                    <td class="text-start details-cell">${escapeHtml(log.details)}</td>
                    <td class="ip-cell">${escapeHtml(log.ip_address)}</td>
                </tr>
            `).join('');
        }

        // 執行篩選 (使用範例資料)
        function applyFilters() {
            const start = el('filterStartDate').value;
            const end = el('filterEndDate').value;
            const userId = el('filterUser').value;
            const action = el('filterAction').value;

            const filteredLogs = sampleLogs.filter(log => {
                if (start && log.timestamp < start + ' 00:00:00') return false;
                // 注意: 結束日期需包含當天 23:59:59
                if (end && log.timestamp > end + ' 23:59:59') return false;
                if (userId && String(log.user_id) !== userId) return false;
                if (action && log.action_type !== action) return false;
                return true;
            });
            renderTable(filteredLogs);
        }

        // 清除篩選條件
        function clearFilters() {
            el('filterStartDate').value = '';
            el('filterEndDate').value = '';
            el('filterUser').value = '';
            el('filterAction').value = '';
            applyFilters(); // 重新顯示所有 (範例) 資料
        }

        // 頁面載入完成後執行的動作
        window.addEventListener('DOMContentLoaded', () => {
            loadLoggedInUser(); // 載入 Navbar 和 Sidebar Footer 的使用者名稱
            loadUserFilter();   // 載入篩選器中的使用者列表 (目前用範例)
            applyFilters();     // 初始顯示所有 (範例) 記錄

            // 綁定篩選按鈕事件
            el('btnFilter').addEventListener('click', applyFilters);
            el('btnClearFilter').addEventListener('click', clearFilters);
            // (可選) 讓篩選器變更時自動查詢
            // ['filterStartDate', 'filterEndDate', 'filterUser', 'filterAction'].forEach(id => {
            //     el(id).addEventListener('change', applyFilters);
            // });
        });

        // 頁面載入時的日期顯示
        el('currentDate').textContent = new Date().toLocaleDateString('zh-TW', { year: 'numeric', month: 'long', day: 'numeric', weekday: 'long' });

    </script>
    </body>
</html>