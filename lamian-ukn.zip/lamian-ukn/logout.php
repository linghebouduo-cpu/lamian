<?php
// /lamian-ukn/logout.php
session_start();
$_SESSION = [];
session_destroy();
header('Location: /lamian-ukn/login.php');
exit;
