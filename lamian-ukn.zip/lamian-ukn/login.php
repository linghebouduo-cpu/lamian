<?php
// 依你的實際路徑修改（這裡假設 /lamian-ukn/api）
$API_BASE = '/lamian-ukn/api';
?>
<!doctype html>
<html lang="zh-Hant">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>員工管理系統 - 登入</title>

  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet"/>
  <style>
    * { box-sizing: border-box; }
    
    body {
      min-height: 100vh;
      background: linear-gradient(135deg, #fbb97c 0%, #ff5a5a 100%);
      display: flex;
      align-items: center;
      justify-content: center;
      padding: 20px;
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
      position: relative;
      overflow: hidden;
    }
    
    body::before {
      content: '';
      position: absolute;
      width: 500px;
      height: 500px;
      background: rgba(255, 255, 255, 0.08);
      border-radius: 50%;
      top: -150px;
      right: -100px;
      pointer-events: none;
    }
    
    body::after {
      content: '';
      position: absolute;
      width: 300px;
      height: 300px;
      background: rgba(255, 255, 255, 0.05);
      border-radius: 50%;
      bottom: -80px;
      left: -50px;
      pointer-events: none;
    }
    
    .login-container {
      position: relative;
      z-index: 10;
    }
    
    .card {
      width: 100%;
      max-width: 600px;
      border: none;
      border-radius: 24px;
      box-shadow: 0 20px 60px rgba(0, 0, 0, 0.3), 0 0 1px rgba(0, 0, 0, 0.1);
      overflow: hidden;
      backdrop-filter: blur(10px);
      animation: slideUp 0.6s cubic-bezier(0.34, 1.56, 0.64, 1);
    }
    
    @keyframes slideUp {
      from {
        opacity: 0;
        transform: translateY(30px);
      }
      to {
        opacity: 1;
        transform: translateY(0);
      }
    }
    
    .card-header {
      background: linear-gradient(135deg, #fbb97c 0%, #ff5a5a 100%);
      color: #fff;
      padding: 32px 28px;
      text-align: center;
      position: relative;
    }
    
    .card-header::after {
      content: '';
      position: absolute;
      bottom: 0;
      left: 0;
      right: 0;
      height: 1px;
      background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.3), transparent);
    }
    
    .card-header h1 {
      font-size: 24px;
      margin: 0;
      font-weight: 700;
      display: flex;
      gap: 12px;
      align-items: center;
      justify-content: center;
      letter-spacing: -0.5px;
    }
    
    .card-header i {
      font-size: 28px;
    }
    
    .card-header p {
      margin: 10px 0 0;
      opacity: 0.95;
      font-size: 14px;
      font-weight: 500;
    }
    
    .card-body {
      padding: 40px 36px;
      background: #fff;
    }
    
    .form-label {
      font-weight: 700;
      color: #2d3748;
      font-size: 14px;
      margin-bottom: 8px;
      display: flex;
      align-items: center;
      gap: 4px;
    }
    
    .input-group-icon {
      position: relative;
      margin-bottom: 16px;
    }
    
    .input-group-icon i {
      position: absolute;
      left: 14px;
      top: 50%;
      transform: translateY(-50%);
      color: #a0aec0;
      font-size: 16px;
      transition: color 0.3s ease;
    }
    
    .input-group-icon .form-control {
      padding: 14px 48px;
      border-radius: 12px;
      border: 2px solid #e2e8f0;
      background: #f7fafc;
      font-size: 14px;
      font-weight: 500;
      transition: all 0.3s ease;
      color: #2d3748;
    }
    
    .input-group-icon .form-control::placeholder {
      color: #cbd5e0;
      font-weight: 400;
    }
    
    .input-group-icon .form-control:focus {
      border-color: #ff5a5a;
      background: #fff;
      box-shadow: 0 0 0 4px rgba(255, 90, 90, 0.1);
      outline: none;
    }
    
    .input-group-icon:focus-within i {
      color: #ff5a5a;
    }
    
    .forgot-container {
      display: flex;
      justify-content: flex-end;
      margin-bottom: 24px;
    }
    
    .forgot {
      color: #ff5a5a;
      font-weight: 600;
      text-decoration: none;
      font-size: 13px;
      display: flex;
      align-items: center;
      gap: 4px;
      transition: all 0.3s ease;
    }
    
    .forgot:hover {
      color: #fbb97c;
      transform: translateX(2px);
    }
    
    .btn-grad {
      background: linear-gradient(135deg, #fbb97c 0%, #ff5a5a 100%);
      border: none;
      color: #fff;
      border-radius: 12px;
      padding: 12px 20px;
      font-weight: 700;
      letter-spacing: 0.5px;
      font-size: 15px;
      transition: all 0.3s cubic-bezier(0.34, 1.56, 0.64, 1);
      box-shadow: 0 4px 15px rgba(255, 90, 90, 0.3);
      cursor: pointer;
      position: relative;
      overflow: hidden;
    }
    
    .btn-grad::before {
      content: '';
      position: absolute;
      top: 0;
      left: -100%;
      width: 100%;
      height: 100%;
      background: rgba(255, 255, 255, 0.2);
      transition: left 0.3s ease;
    }
    
    .btn-grad:hover {
      transform: translateY(-2px);
      box-shadow: 0 6px 25px rgba(255, 90, 90, 0.4);
    }
    
    .btn-grad:hover::before {
      left: 100%;
    }
    
    .btn-grad:active {
      transform: translateY(0);
    }
    
    .btn-grad:disabled {
      opacity: 0.7;
      cursor: not-allowed;
      transform: none;
    }
    
    .alert {
      border: none;
      border-radius: 12px;
      font-size: 14px;
      font-weight: 500;
      padding: 12px 16px;
      margin-bottom: 20px;
      animation: slideDown 0.3s ease;
    }
    
    @keyframes slideDown {
      from {
        opacity: 0;
        transform: translateY(-10px);
      }
      to {
        opacity: 1;
        transform: translateY(0);
      }
    }
    
    .alert-success {
      background: #f0fdf4;
      color: #166534;
      border-left: 4px solid #22c55e;
    }
    
    .alert-danger {
      background: #fef2f2;
      color: #991b1b;
      border-left: 4px solid #ef4444;
    }
    
    .modal-content {
      border: none;
      border-radius: 20px;
      box-shadow: 0 20px 60px rgba(0, 0, 0, 0.3);
    }
    
    .modal-header {
      background: linear-gradient(135deg, #fbb97c 0%, #ff5a5a 100%);
      color: #fff;
      border: none;
      border-radius: 20px 20px 0 0;
      padding: 24px 28px;
    }
    
    .modal-header .btn-close {
      filter: brightness(0) invert(1);
      opacity: 0.7;
    }
    
    .modal-header .btn-close:hover {
      opacity: 1;
    }
    
    .modal-title {
      font-weight: 700;
      font-size: 18px;
    }
    
    .modal-body {
      padding: 28px;
    }
    
    .modal-footer {
      border-top: 1px solid #e2e8f0;
      padding: 20px 28px;
      background: #f7fafc;
      border-radius: 0 0 20px 20px;
    }
    
    .modal-footer .btn {
      border-radius: 10px;
      padding: 10px 18px;
      font-weight: 600;
      font-size: 14px;
    }
    
    .btn-outline-secondary {
      border: 1.5px solid #cbd5e0;
      color: #4a5568;
    }
    
    .btn-outline-secondary:hover {
      background: #edf2f7;
      border-color: #a0aec0;
    }
    
    .fp-step { display: none; }
    .fp-step.active { display: block; animation: fadeIn 0.3s ease; }
    
    @keyframes fadeIn {
      from { opacity: 0; }
      to { opacity: 1; }
    }
    
    .spinner-border {
      width: 1em;
      height: 1em;
    }
  </style>
</head>
<body>

<div class="login-container">
  <div class="card">
    <div class="card-header">
      <h1><i class="bi bi-shield-lock"></i>員工管理系統</h1>
      <p>歡迎回來，請登入您的帳號</p>
    </div>
    <div class="card-body">
      <div id="loginMsg" class="alert d-none"></div>

      <div class="mb-3">
        <label class="form-label">
          <i class="bi bi-person"></i>帳號
        </label>
        <div class="input-group-icon">
          <i class="bi bi-person"></i>
          <input id="acc" class="form-control" placeholder="輸入帳號">
        </div>
      </div>

      <div class="mb-3">
        <label class="form-label">
          <i class="bi bi-lock"></i>密碼
        </label>
        <div class="input-group-icon">
          <i class="bi bi-lock"></i>
          <input id="pwd" type="password" class="form-control" placeholder="輸入密碼">
        </div>
      </div>

      <div class="forgot-container">
        <a class="forgot" href="#" data-bs-toggle="modal" data-bs-target="#fpModal">
          <i class="bi bi-question-circle"></i>忘記密碼？
        </a>
      </div>

      <button id="btnLogin" class="btn btn-grad w-100">
        <i class="bi bi-box-arrow-in-right me-2"></i>立即登入
      </button>
    </div>
  </div>
</div>

<!-- 忘記密碼 Modal（三步驟） -->
<div class="modal fade" id="fpModal" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">重設密碼</h5>
        <button class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body">
        <div id="fpMsg" class="alert d-none"></div>

        <!-- Step 1 -->
        <div class="fp-step fp-1 active">
          <label class="form-label">
            <i class="bi bi-envelope"></i>電子郵件地址
          </label>
          <div class="input-group-icon">
            <i class="bi bi-envelope"></i>
            <input id="fpEmail" type="email" class="form-control" placeholder="name@example.com">
          </div>
          <small class="text-muted d-block mt-2" style="font-size: 13px;">我們會寄出 <b>6 碼驗證碼</b>，10 分鐘內有效。</small>
        </div>

        <!-- Step 2 -->
        <div class="fp-step fp-2">
          <label class="form-label">
            <i class="bi bi-123"></i>輸入 6 碼驗證碼
          </label>
          <div class="input-group-icon">
            <i class="bi bi-123"></i>
            <input id="fpCode" maxlength="6" class="form-control" placeholder="例如 123456">
          </div>
        </div>

        <!-- Step 3 -->
        <div class="fp-step fp-3">
          <label class="form-label">
            <i class="bi bi-shield-lock"></i>新密碼
          </label>
          <div class="input-group-icon">
            <i class="bi bi-shield-lock"></i>
            <input id="fpPwd1" type="password" class="form-control" placeholder="至少 6 碼">
          </div>
          <label class="form-label mt-3">
            <i class="bi bi-shield-lock-fill"></i>確認新密碼
          </label>
          <div class="input-group-icon">
            <i class="bi bi-shield-lock-fill"></i>
            <input id="fpPwd2" type="password" class="form-control" placeholder="再輸入一次">
          </div>
        </div>
      </div>
      <div class="modal-footer">
        <button id="fpPrev" class="btn btn-outline-secondary" style="display:none">
          <i class="bi bi-chevron-left me-1"></i>上一步
        </button>
        <button class="btn btn-outline-secondary" data-bs-dismiss="modal">取消</button>
        <button id="fpNext" class="btn btn-grad">
          <span id="fpNextText">寄送驗證碼</span>
        </button>
      </div>
    </div>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
const API_LOGIN  = <?php echo json_encode($API_BASE . '/auth_login.php'); ?>;
const API_SEND   = <?php echo json_encode($API_BASE . '/password_request.php'); ?>;
const API_VERIFY = <?php echo json_encode($API_BASE . '/password_verify.php'); ?>;
const API_RESET  = <?php echo json_encode($API_BASE . '/password_reset.php'); ?>;

const $ = s => document.querySelector(s);
function showMsg(el, text, ok=false){
  el.className = 'alert ' + (ok? 'alert-success':'alert-danger');
  el.textContent = text; el.classList.remove('d-none');
  setTimeout(()=> el.classList.add('d-none'), ok? 2200: 4200);
}

// 登入
$('#btnLogin').addEventListener('click', async ()=>{
  const account = $('#acc').value.trim();
  const password = $('#pwd').value;
  if(!account || !password){ showMsg($('#loginMsg'),'請輸入帳號與密碼'); return; }

  const btn = $('#btnLogin'); const old = btn.innerHTML;
  btn.disabled = true; btn.innerHTML = '<span class="spinner-border spinner-border-sm me-2"></span>登入中...';

  try{
    const r = await fetch(API_LOGIN, {
      method:'POST', headers:{'Content-Type':'application/json'},
      body: JSON.stringify({account, password}), credentials:'include'
    });
    const t = await r.text(); let resp; try{ resp = JSON.parse(t);}catch{ throw new Error('登入 API 非 JSON：'+t.slice(0,80)); }
    if(!r.ok || resp.error) throw new Error(resp.error || ('HTTP '+r.status));
    showMsg($('#loginMsg'),'登入成功，前往首頁...', true);
    setTimeout(()=> location.href='index.php', 700);
  }catch(e){
    showMsg($('#loginMsg'), String(e.message||e));
  }finally{
    btn.disabled=false; btn.innerHTML=old;
  }
});
['#acc','#pwd'].forEach(s=> $(s).addEventListener('keypress',e=>{ if(e.key==='Enter') $('#btnLogin').click(); }));

// 忘記密碼流程
let FP_STEP=1, FP_RESET_ID=null, FP_EMAIL='';
function setStep(n){
  FP_STEP=n;
  document.querySelectorAll('.fp-step').forEach(n=>n.classList.remove('active'));
  $('.fp-'+n).classList.add('active');
  $('#fpPrev').style.display = (n>1)?'inline-block':'none';
  $('#fpNextText').textContent = n===1? '寄送驗證碼' : n===2? '驗證' : '重設密碼';
}
$('#fpPrev').addEventListener('click', ()=> setStep(FP_STEP-1||1));

$('#fpNext').addEventListener('click', async ()=>{
  const btn = $('#fpNext'); const old = btn.innerHTML;
  btn.disabled=true; btn.innerHTML='<span class="spinner-border spinner-border-sm me-2"></span>處理中...';
  try{
    if(FP_STEP===1){
      FP_EMAIL = $('#fpEmail').value.trim();
      if(!FP_EMAIL){ showMsg($('#fpMsg'),'請輸入 Email'); return; }
      const r = await fetch(API_SEND,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({email:FP_EMAIL})});
      const t = await r.text(); let resp; try{ resp=JSON.parse(t);}catch{ throw new Error('Unexpected: '+t.slice(0,120)); }
      if(!r.ok || !resp.ok) throw new Error(resp.error || ('HTTP '+r.status));
      FP_RESET_ID = resp.reset_id || null;
      showMsg($('#fpMsg'),'驗證碼已寄出，請收信',true); setStep(2);
    }else if(FP_STEP===2){
      const code = $('#fpCode').value.trim();
      if(code.length!==6){ showMsg($('#fpMsg'),'請輸入 6 碼驗證碼'); return; }
      const r = await fetch(API_VERIFY,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({email:FP_EMAIL, code})});
      const t = await r.text(); let resp; try{ resp=JSON.parse(t);}catch{ throw new Error('Unexpected: '+t.slice(0,120)); }
      if(!r.ok || !resp.ok) throw new Error(resp.error || ('HTTP '+r.status));
      window.__RESET_TOKEN__ = resp.reset_token;
      showMsg($('#fpMsg'),'驗證通過，請設定新密碼',true); setStep(3);
    }else{
      const p1=$('#fpPwd1').value.trim(), p2=$('#fpPwd2').value.trim();
      if(p1.length<6)        { showMsg($('#fpMsg'),'新密碼至少 6 碼'); return; }
      if(p1!==p2)            { showMsg($('#fpMsg'),'兩次密碼不一致'); return; }
      const r = await fetch(API_RESET,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({email:FP_EMAIL, reset_token:window.__RESET_TOKEN__, new_password:p1})});
      const t = await r.text(); let resp; try{ resp=JSON.parse(t);}catch{ throw new Error('Unexpected: '+t.slice(0,120)); }
      if(!r.ok || !resp.ok) throw new Error(resp.error || ('HTTP '+r.status));
      showMsg($('#fpMsg'),'密碼已重設，請用新密碼登入',true);
      setTimeout(()=> bootstrap.Modal.getInstance(document.getElementById('fpModal'))?.hide(), 1000);
    }
  }catch(e){ showMsg($('#fpMsg'), String(e.message||e)); }
  finally{ btn.disabled=false; btn.innerHTML=old; }
});
document.getElementById('fpModal').addEventListener('show.bs.modal', ()=>{
  $('#fpMsg').classList.add('d-none');
  ['#fpEmail','#fpCode','#fpPwd1','#fpPwd2'].forEach(s=> $(s).value='');
  setStep(1); FP_EMAIL=''; window.__RESET_TOKEN__='';
});
</script>
</body>
</html>