<!DOCTYPE html>

<html lang="zh-Hant">

<head>

  <meta charset="utf-8" />

  <meta http-equiv="X-UA-Compatible" content="IE=edge" />

  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />

  <title>打卡記錄 - 員工管理系統</title>



  <!-- 與其他頁一致 -->

  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" />

  <link href="https://cdn.jsdelivr.net/npm/simple-datatables@7.1.2/dist/style.min.css" rel="stylesheet" />

  <link href="css/styles.css" rel="stylesheet" />

  <script src="https://use.fontawesome.com/releases/v6.3.0/js/all.js" crossorigin="anonymous"></script>



  <style>

     :root {

      --primary-gradient: linear-gradient(135deg, #fbb97ce4 0%, #ff0000cb 100%); /* 首頁同色 */

      --secondary-gradient: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);

      --success-gradient: linear-gradient(135deg, #4facfe 0%, #54bcc1 100%);

      --warning-gradient: linear-gradient(135deg, #fbb97ce4 0%, #ff00006a 100%);

      --dark-bg: linear-gradient(135deg, #fbb97ce4 0%, #ff00006a 100%);

      --card-shadow: 0 15px 35px rgba(0,0,0,.1);

      --hover-shadow: 0 25px 50px rgba(0,0,0,.15);

      --border-radius: 20px;

      --transition: all .3s cubic-bezier(.4,0,.2,1);

    }

    * { transition: var(--transition); }

    body {

      background: linear-gradient(135deg, #ffffff 0%, #ffffff 100%);

      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;

      min-height: 100vh;

    }



    /* 頂欄（跟首頁一致） */

    .sb-topnav {

      background: var(--dark-bg) !important;

      border: none;

      box-shadow: var(--card-shadow);

      backdrop-filter: blur(10px);

    }

    .navbar-brand {

      font-weight: 700;

      font-size: 1.5rem;

      background: linear-gradient(45deg, #ffffff, #ffffff);

      /* 修復 Lint：標準屬性 + 前綴 + 透明文字 */

      background-clip: text;

      -webkit-background-clip: text;

      color: transparent;

      -webkit-text-fill-color: transparent;

      text-shadow: none;

    }



    /* 側欄（跟首頁一致） */

    .sb-sidenav {

      background: linear-gradient(180deg, #fbb97ce4 0%, #ff00006a 100%) !important;

      box-shadow: var(--card-shadow);

      backdrop-filter: blur(10px);

    }

    .sb-sidenav-menu-heading {

      color: rgba(255,255,255,.7) !important;

      font-weight: 600;

      font-size: .85rem;

      text-transform: uppercase;

      letter-spacing: 1px;

      padding: 20px 15px 10px 15px !important;

      margin-top: 15px;

    }

    .sb-sidenav .nav-link {

      border-radius: 15px;

      margin: 5px 15px;

      padding: 12px 15px;

      position: relative;

      overflow: hidden;

      color: rgba(255,255,255,.9) !important;

      font-weight: 500;

      backdrop-filter: blur(10px);

    }

    .sb-sidenav .nav-link:hover {

      background: rgba(255,255,255,.15) !important;

      transform: translateX(8px);

      box-shadow: 0 8px 25px rgba(0,0,0,.2);

      color: #fff !important;

    }

    .sb-sidenav .nav-link.active {

      background: rgba(255,255,255,.2) !important;

      color: #fff !important;

      font-weight: 600;

      box-shadow: 0 8px 25px rgba(0,0,0,.15);

    }

    .sb-sidenav .nav-link::before {

      content: '';

      position: absolute; left: 0; top: 0; height: 100%; width: 4px;

      background: linear-gradient(45deg, #ffffff, #ffffff); /* 和首頁相同：白色亮條 */

      transform: scaleY(0);

      transition: var(--transition);

      border-radius: 0 10px 10px 0;

    }

    .sb-sidenav .nav-link:hover::before,

    .sb-sidenav .nav-link.active::before { transform: scaleY(1); }



    .sb-sidenav .nav-link i { width: 20px; text-align: center; margin-right: 10px; font-size: 1rem; }

    .sb-sidenav-footer {

      background: rgba(255,255,255,.1) !important;

      color: #fff !important;

      border-top: 1px solid rgba(255,255,255,.2);

      padding: 20px 15px;

      margin-top: 20px;

    }

    /* 內容/卡片/表格 */

    .container-fluid{padding:30px!important}

    h1{

      background:var(--primary-gradient);

      background-clip:text; -webkit-background-clip:text;

      color:transparent; -webkit-text-fill-color:transparent;

      font-weight:700; font-size:2.2rem; margin-bottom:0

    }

    .breadcrumb{background:rgba(255,255,255,.8); border-radius:var(--border-radius); padding:12px 16px; box-shadow:var(--card-shadow); backdrop-filter:blur(10px)}

    .card{border:none; border-radius:var(--border-radius); box-shadow:var(--card-shadow); background:#fff}

    .card-header{background:linear-gradient(135deg,rgba(255,255,255,.9),rgba(255,255,255,.7)); font-weight:600}

    .table{border-radius:var(--border-radius); overflow:hidden; background:#fff; box-shadow:var(--card-shadow)}

    .table thead th{background:var(--primary-gradient); color:#000; border:none; font-weight:600; padding:12px}

    .table tbody td{padding:12px; vertical-align:middle; border-color:rgba(0,0,0,.05)}

    .table-hover tbody tr:hover{background:rgba(227,23,111,.05); transform:scale(1.01)}



    .badge-status{border-radius:999px; padding:.35rem .6rem; border:1px solid transparent}

    .badge-normal{background:rgba(25,135,84,.15); border-color:rgba(25,135,84,.35); color:#0f5132}

    .badge-ot{background:rgba(13,110,253,.15); border-color:rgba(13,110,253,.35); color:#084298}

    .badge-missing{background:rgba(220,53,69,.15); border-color:rgba(220,53,69,.35); color:#842029}



    .btn-primary{background:var(--primary-gradient); border:none; border-radius:25px}

    .btn-primary:hover{transform:scale(1.05); box-shadow:0 10px 25px rgba(209,209,209,.9)}

  </style>

</head>



<body class="sb-nav-fixed">

  <!-- Navbar -->

  <nav class="sb-topnav navbar navbar-expand navbar-dark bg-dark">

    <a class="navbar-brand ps-3" href="index.html">員工管理系統</a>

    <button class="btn btn-link btn-sm order-1 order-lg-0 me-4 me-lg-0" id="sidebarToggle" type="button">

      <i class="fas fa-bars"></i>

    </button>



    <form class="d-none d-md-inline-block form-inline ms-auto me-0 me-md-3 my-2 my-md-0">

      <div class="input-group">

        <input class="form-control" type="text" placeholder="Search for..." aria-label="Search" />

        <button class="btn btn-primary" id="btnNavbarSearch" type="button"><i class="fas fa-search"></i></button>

      </div>

    </form>



    <ul class="navbar-nav ms-auto ms-md-0 me-3 me-lg-4">

      <li class="nav-item dropdown">

        <a class="nav-link dropdown-toggle" id="navbarDropdown" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">

          <i class="fas fa-user fa-fw"></i>

        </a>

        <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">

          <li><a class="dropdown-item" href="#!">Settings</a></li>

          <li><a class="dropdown-item" href="#!">Activity Log</a></li>

          <li><hr class="dropdown-divider" /></li>

          <li><a class="dropdown-item" href="#!">Logout</a></li>

        </ul>

      </li>

    </ul>

  </nav>

  <div id="layoutSidenav">

    <!-- Side Nav -->

    <div id="layoutSidenav_nav">

      <nav class="sb-sidenav accordion sb-sidenav-dark" id="sidenavAccordion">

        <div class="sb-sidenav-menu">

          <div class="nav">

            <div class="sb-sidenav-menu-heading">Core</div>

            <a class="nav-link" href="index.html">

              <div class="sb-nav-link-icon"><i class="fas fa-tachometer-alt"></i></div>首頁

            </a>



            <div class="sb-sidenav-menu-heading">Pages</div>

            <a class="nav-link collapsed" href="#" data-bs-toggle="collapse" data-bs-target="#collapseLayouts" aria-expanded="false">

              <div class="sb-nav-link-icon"><i class="fas fa-columns"></i></div>人事管理

              <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>

            </a>

            <div class="collapse" id="collapseLayouts" data-bs-parent="#sidenavAccordion">

              <nav class="sb-sidenav-menu-nested nav">

                <a class="nav-link" href="員工資料表.html">員工資料表</a>

                <a class="nav-link" href="班表管理.html">班表管理</a>

                <a class="nav-link" href="日報表記錄.html">日報表記錄</a>

                <a class="nav-link" href="假別管理.html">假別管理</a>

                <a class="nav-link" href="打卡記錄.html">打卡紀錄</a>

                <a class="nav-link" href="薪資管理.html">薪資管理</a>

              </nav>

            </div>



            <a class="nav-link collapsed" href="#" data-bs-toggle="collapse" data-bs-target="#collapseOperation" aria-expanded="false">

              <div class="sb-nav-link-icon"><i class="fas fa-chart-line"></i></div>營運管理

              <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>

            </a>

            <div class="collapse" id="collapseOperation" data-bs-parent="#sidenavAccordion">

              <nav class="sb-sidenav-menu-nested nav accordion" id="sidenavAccordionOperation">

                <a class="nav-link collapsed" href="#" data-bs-toggle="collapse" data-bs-target="#operationCollapseInventory" aria-expanded="false">

                  庫存管理

                  <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>

                </a>

                <div class="collapse" id="operationCollapseInventory" data-bs-parent="#sidenavAccordionOperation">

                  <nav class="sb-sidenav-menu-nested nav">

                    <a class="nav-link" href="庫存查詢.html">庫存查詢</a>

                    <a class="nav-link" href="庫存調整.html">庫存調整</a>

                  </nav>

                </div>



                <a class="nav-link" href="日報表.html"><div class="sb-nav-link-icon"></div>日報表</a>

                <a class="nav-link" href="薪資記錄.html"><div class="sb-nav-link-icon"></i></div>薪資記錄</a>

                <a class="nav-link" href="班表.html"><div class="sb-nav-link-icon"></div>班表</a>



              </nav>

            </div>

     

                <a class="nav-link" href="請假申請.html"><div class="sb-nav-link-icon"><i class="fas fa-calendar-alt"></i></div>請假申請</a>



            <a class="nav-link collapsed" href="#" data-bs-toggle="collapse" data-bs-target="#collapseWebsite" aria-expanded="false">

              <div class="sb-nav-link-icon"><i class="fas fa-cogs"></i></div>網站管理

              <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>

            </a>

            <div class="collapse" id="collapseWebsite" data-bs-parent="#sidenavAccordion">

              <nav class="sb-sidenav-menu-nested nav accordion" id="sidenavAccordionWebsite">

                <a class="nav-link" href="layout-static.html">官網資料修改</a>

                <a class="nav-link collapsed" href="#" data-bs-toggle="collapse" data-bs-target="#websiteCollapseMember" aria-expanded="false">

                  會員管理

                  <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>

                </a>

                <div class="collapse" id="websiteCollapseMember" data-bs-parent="#sidenavAccordionWebsite">

                  <nav class="sb-sidenav-menu-nested nav">

                    <a class="nav-link" href="member-list.html">會員清單</a>

                    <a class="nav-link" href="member-detail.html">詳細資料頁</a>

                    <a class="nav-link" href="point-manage.html">點數管理</a>

                  </nav>

                </div>

              </nav>

            </div>



            <div class="sb-sidenav-menu-heading">Addons</div>

            <a class="nav-link" href="charts.html"><div class="sb-nav-link-icon"><i class="fas fa-chart-area"></i></div>Charts</a>

            <a class="nav-link" href="tables.html"><div class="sb-nav-link-icon"><i class="fas fa-table"></i></div>Tables</a>

          </div>

        </div>



        <div class="sb-sidenav-footer">

          <div class="small">Logged in as:</div>

          Start Bootstrap

        </div>

      </nav>

    </div>



    <!-- Content -->

    <div id="layoutSidenav_content">

      <main>

        <div class="container-fluid">

          <div class="d-flex justify-content-between align-items-center mb-3">

            <h1>打卡記錄</h1>

            <div class="text-muted"><i class="fas fa-calendar-alt me-2"></i><span id="currentDate"></span></div>

          </div>



          <ol class="breadcrumb mb-4">

            <li class="breadcrumb-item"><a href="index.html" class="text-decoration-none">首頁</a></li>

            <li class="breadcrumb-item active">打卡記錄</li>

          </ol>



          <!-- 篩選列 -->

          <div class="card mb-4">

            <div class="card-body">

              <div class="row g-3">

                <div class="col-md-3">

                  <label class="form-label">開始日期</label>

                  <input type="date" class="form-control" id="start_date">

                </div>

                <div class="col-md-3">

                  <label class="form-label">結束日期</label>

                  <input type="date" class="form-control" id="end_date">

                </div>

                <div class="col-md-3">

                  <label class="form-label">員工</label>

                  <select class="form-control" id="employee_filter">

                    <option value="">全部</option>

                  </select>

                </div>

                <div class="col-md-3">

                  <label class="form-label">狀態</label>

                  <select class="form-control" id="status_filter">

                    <option value="">全部</option>

                    <option value="正常">正常</option>

                    <option value="缺卡">缺卡</option>

                    <option value="加班">加班</option>

                  </select>

                </div>

                <div class="col-12 d-flex align-items-end justify-content-end gap-2">

                  <button class="btn btn-primary" id="btnSearch"><i class="fas fa-search me-1"></i> 查詢</button>

                  <button class="btn btn-secondary" id="btnClear"><i class="fas fa-eraser me-1"></i> 清除</button>

                  <button class="btn btn-success" id="btnExport"><i class="fas fa-file-export me-1"></i> 匯出CSV</button>

                </div>

              </div>

            </div>

          </div>



          <!-- 摘要 -->

          <div class="row mb-4">

            <div class="col-xl-3 col-md-6">

              <div class="card text-white mb-4" style="background: var(--success-gradient);">

                <div class="card-body">

                  <div class="d-flex justify-content-between">

                    <div>

                      <div class="small text-white-50">總工時（小時）</div>

                      <div class="h5" id="sum_hours">-</div>

                    </div>

                    <i class="fas fa-clock fa-2x text-white-50"></i>

                  </div>

                </div>

              </div>

            </div>

            <div class="col-xl-3 col-md-6">

              <div class="card text-white mb-4" style="background: var(--primary-gradient);">

                <div class="card-body">

                  <div class="d-flex justify-content-between">

                    <div>

                      <div class="small text-white-50">出勤筆數</div>

                      <div class="h5" id="sum_records">-</div>

                    </div>

                    <i class="fas fa-list-check fa-2x text-white-50"></i>

                  </div>

                </div>

              </div>

            </div>

            <div class="col-xl-3 col-md-6">

              <div class="card text-white mb-4" style="background: var(--warning-gradient);">

                <div class="card-body">

                  <div class="d-flex justify-content-between">

                    <div>

                      <div class="small text-white-50">缺卡筆數</div>

                      <div class="h5" id="sum_missing">-</div>

                    </div>

                    <i class="fas fa-triangle-exclamation fa-2x text-white-50"></i>

                  </div>

                </div>

              </div>

            </div>

            <div class="col-xl-3 col-md-6">

              <div class="card text-white mb-4" style="background: var(--secondary-gradient);">

                <div class="card-body">

                  <div class="d-flex justify-content-between">

                    <div>

                      <div class="small text-white-50">加班（小時）</div>

                      <div class="h5" id="sum_ot">-</div>

                    </div>

                    <i class="fas fa-bolt fa-2x text-white-50"></i>

                  </div>

                </div>

              </div>

            </div>

          </div>



          <!-- 表格 -->

          <div class="card mb-4">

            <div class="card-header"><i class="fas fa-table me-1"></i>打卡記錄列表</div>

            <div class="card-body">

              <div class="table-responsive">

                <table class="table table-bordered table-hover align-middle">

                  <thead>

                    <tr>

                      <th>員工編號</th>

                      <th>員工姓名</th>

                      <th>員工帳號</th>

                      <th>打卡日期</th>

                      <th>上班/下班時間</th>

                      <th>打卡地點</th>

                      <th>工作時數（小時）</th>

                      <th>狀態</th>

                    </tr>

                  </thead>

                  <tbody id="attTableBody">

                    <tr><td colspan="8" class="text-center text-muted py-4">載入中…</td></tr>

                  </tbody>

                </table>

              </div>

            </div>

          </div>



        </div>

      </main>



      <footer class="py-4 bg-light mt-auto">

        <div class="container-fluid px-4">

          <div class="d-flex align-items-center justify-content-between small">

            <div class="text-muted">Copyright &copy; Xxing0625</div>

            <div>

              <a href="#">Privacy Policy</a> &middot; <a href="#">Terms &amp; Conditions</a>

            </div>

          </div>

        </div>

      </footer>

    </div>

  </div>



  <!-- JS -->

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>

  <script>

    // ===== 共用：今日日期 / 側欄 =====

    document.getElementById('currentDate').textContent =

      new Date().toLocaleDateString('zh-TW',{year:'numeric',month:'long',day:'numeric',weekday:'long'});

    document.getElementById('sidebarToggle').addEventListener('click', e=>{

      e.preventDefault(); document.body.classList.toggle('sb-sidenav-toggled');

    });



    // ===== API 設定（改成你的）=====

    const API_BASE = '/api';



    const API = {

      async request(path, options={}){

        const res = await fetch(API_BASE + path, {

          headers: {'Content-Type':'application/json', ...(options.headers||{})},

          ...options

        });

        if(!res.ok) throw new Error(res.status + ' ' + res.statusText);

        return await res.json();

      },

      // 取得員工（用來帶下拉）

      getEmployees(){ return this.request('/employees'); },

      // 取得打卡：GET /attendance?start_date=YYYY-MM-DD&end_date=YYYY-MM-DD&employee_id=?

      getAttendance(params={}){

        const qs = new URLSearchParams(params).toString();

        return this.request('/attendance' + (qs?('?'+qs):''));

      }

    };



    // ===== 工具：時間/時數計算 =====

    function parseHHMM(t){ // "18:05" -> 分鐘

      if(!t) return null;

      const [h,m] = t.split(':').map(Number);

      if(Number.isNaN(h) || Number.isNaN(m)) return null;

      return h*60+m;

    }

    // 跨日處理：若下班分鐘 < 上班分鐘，補 +1440

    function minutesBetween(inStr, outStr){

      const inMin = parseHHMM(inStr), outMin = parseHHMM(outStr);

      if(inMin==null || outMin==null) return null;

      let diff = outMin - inMin;

      if(diff < 0) diff += 1440;

      return diff;

    }

    function hr2fixed(mins){ return (Math.round((mins/60)*100)/100).toFixed(2); } // 小時(兩位)

    function statusBadge(status){

      const s = (status||'').toLowerCase();

      if(s==='缺卡' || s==='missing') return '<span class="badge-status badge-missing">缺卡</span>';

      if(s==='加班' || s==='ot') return '<span class="badge-status badge-ot">加班</span>';

      return '<span class="badge-status badge-normal">正常</span>';

    }



    // ===== 狀態推論（無班表時的基礎規則）=====

    // 規則：

    // 1) 任一邊缺 -> 缺卡

    // 2) 工時>8h -> 加班（同時不標「正常」）

    function inferStatus(rec, mins){

      if(!rec.clock_in || !rec.clock_out) return '缺卡';

      if(mins!=null && mins>8*60) return '加班';

      return '正常';

    }



    // ===== UI & 資料 =====

    let RAW = []; // 原始打卡

    let FILTERED = []; // 篩後



    function setDefaultDates(){

      const end = new Date();

      const start = new Date(); start.setDate(end.getDate()-13); // 最近14天

      document.getElementById('end_date').value = end.toISOString().slice(0,10);

      document.getElementById('start_date').value = start.toISOString().slice(0,10);

    }



    async function loadEmployees(){

      try{

        const list = await API.getEmployees(); // 期待 {id,name,account...}

        const sel = document.getElementById('employee_filter');

        sel.innerHTML = '<option value="">全部</option>' + (list||[]).map(e=>{

          const id = e.id ?? e.employee_id ?? '';

          const name = e.name ?? '';

          return `<option value="${id}">${name}</option>`;

        }).join('');

      }catch(e){ console.warn('loadEmployees', e); }

    }



    async function loadAttendance(){

      const params = {

        start_date: document.getElementById('start_date').value || '',

        end_date: document.getElementById('end_date').value || ''

      };

      const emp = document.getElementById('employee_filter').value;

      if(emp) params.employee_id = emp;



      try{

        const data = await API.getAttendance(params);

        // 期待每筆：{ employee_id, employee_name, account, date, clock_in:"HH:MM", clock_out:"HH:MM", location, minutes_worked?, status? }

        RAW = Array.isArray(data) ? data : (data?.data || []);

        computeAndRender();

      }catch(e){

        console.warn('loadAttendance', e);

        document.getElementById('attTableBody').innerHTML =

          `<tr><td colspan="8" class="text-danger text-center">載入失敗</td></tr>`;

        setSummary(0,0,0,0);

      }

    }



    function computeAndRender(){

      const statusFilter = document.getElementById('status_filter').value;

      // 先計算 mins/status

      const computed = RAW.map(r=>{

        const mins = (r.minutes_worked!=null) ? Number(r.minutes_worked) : minutesBetween(r.clock_in, r.clock_out);

        const status = r.status || inferStatus(r, mins);

        return {...r, _mins: mins, _status: status};

      });



      // 篩選

      FILTERED = computed.filter(r=>{

        if(!statusFilter) return true;

        return r._status === statusFilter;

      });



      // 渲染表格

      const tbody = document.getElementById('attTableBody');

      if(FILTERED.length===0){

        tbody.innerHTML = `<tr><td colspan="8" class="text-center text-muted py-4">目前沒有資料</td></tr>`;

      }else{

        tbody.innerHTML = FILTERED.map(r=>{

          const timeRange = (r.clock_in||'-') + ' / ' + (r.clock_out||'-');

          const hrs = (r._mins==null) ? '-' : hr2fixed(r._mins);

          return `

            <tr>

              <td>${r.employee_id ?? ''}</td>

              <td>${r.employee_name ?? ''}</td>

              <td>${r.account ?? ''}</td>

              <td>${r.date ?? ''}</td>

              <td>${timeRange}</td>

              <td>${r.location ?? ''}</td>

              <td>${hrs}</td>

              <td>${statusBadge(r._status)}</td>

            </tr>

          `;

        }).join('');

      }



      // 摘要

      const totalMins = FILTERED.reduce((s,r)=> s + (r._mins||0), 0);

      const miss = FILTERED.filter(r=> r._status==='缺卡').length;

      const otMins = FILTERED.reduce((s,r)=> s + ((r._status==='加班') ? (r._mins-8*60) : 0), 0);

      setSummary(hr2fixed(totalMins), FILTERED.length, miss, hr2fixed(otMins));

    }



    function setSummary(sumHours, sumRecords, sumMissing, sumOT){

      document.getElementById('sum_hours').textContent = (sumHours||'0.00');

      document.getElementById('sum_records').textContent = (sumRecords||0);

      document.getElementById('sum_missing').textContent = (sumMissing||0);

      document.getElementById('sum_ot').textContent = (sumOT||'0.00');

    }



    function clearFilters(){

      setDefaultDates();

      document.getElementById('employee_filter').value = '';

      document.getElementById('status_filter').value = '';

    }



    // 匯出 CSV（用目前篩選後的資料）

    function exportCSV(){

      if(!FILTERED.length){

        alert('目前沒有可匯出的資料'); return;

      }

      const headers = ["員工編號","員工姓名","員工帳號","打卡日期","上班/下班時間","打卡地點","工作時數","狀態"];

      const rows = FILTERED.map(r=>[

        r.employee_id ?? '',

        r.employee_name ?? '',

        r.account ?? '',

        r.date ?? '',

        (r.clock_in||'-') + ' / ' + (r.clock_out||'-'),

        r.location ?? '',

        (r._mins==null? '' : hr2fixed(r._mins)),

        r._status

      ]);

      const csv = [headers, ...rows].map(cols =>

        cols.map(v=>{

          const s = String(v ?? '');

          return `"${s.replace(/"/g,'""')}"`;

        }).join(',')

      ).join('\r\n');



      const blob = new Blob([csv], {type:'text/csv;charset=utf-8;'});

      const url = URL.createObjectURL(blob);

      const a = document.createElement('a');

      const today = new Date().toISOString().slice(0,10);

      a.href = url; a.download = `打卡記錄_${today}.csv`;

      document.body.appendChild(a); a.click();

      document.body.removeChild(a);

      URL.revokeObjectURL(url);

    }



    // 初始化

    window.addEventListener('DOMContentLoaded', async ()=>{

      // 日期預設：最近14天

      setDefaultDates();

      // 載入員工下拉

      await loadEmployees();

      // 載入打卡

      await loadAttendance();



      // 事件

      document.getElementById('btnSearch').addEventListener('click', loadAttendance);

      document.getElementById('btnClear').addEventListener('click', ()=>{

        clearFilters(); loadAttendance();

      });

      document.getElementById('status_filter').addEventListener('change', computeAndRender);

      document.getElementById('btnExport').addEventListener('click', exportCSV);

    });

  </script>

</body>

</html>