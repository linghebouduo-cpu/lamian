<?php
// /lamian-ukn/假別管理.php
// 登入保護（如未登入會被導回登入頁）
require_once __DIR__ . '/api/auth_guard.php';

/**
 * 路徑設定
 * - $API_BASE_URL  ：統一放登入／審核等 API（例：/lamian-ukn/api）
 * - $DATA_BASE_URL ：統一放資料查詢 API（例：/lamian-ukn/首頁）
 * - $LEAVE_BASE_URL：本頁用到的「請假」相關 API 目錄（請依你的實際資料夾調整）
 *
 * 你可以依你的專案實際結構修改底下三個變數即可。
 */
$API_BASE_URL   = '/lamian-ukn/api';
$DATA_BASE_URL  = '/lamian-ukn/首頁';
$LEAVE_BASE_URL = '/lamian-ukn/假別管理'; // ⬅️ 建議把「取得請假紀錄.php / 取得審核列表.php / review_leave.php」放在這裡
?>
<!DOCTYPE html>
<html lang="zh-Hant">
<head>
  <meta charset="utf-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
  <title>假別管理 - 員工管理系統</title>

  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" />
  <link href="https://cdn.jsdelivr.net/npm/simple-datatables@7.1.2/dist/style.min.css" rel="stylesheet" />
  <link href="css/styles.css" rel="stylesheet" />
  <script src="https://use.fontawesome.com/releases/v6.3.0/js/all.js" crossorigin="anonymous"></script>

  <style>
    :root {
      --primary-gradient: linear-gradient(135deg, #fbb97ce4 0%, #ff0000cb 100%);
      --secondary-gradient: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);
      --success-gradient: linear-gradient(135deg, #4facfe 0%, #54bcc1 100%);
      --warning-gradient: linear-gradient(135deg, #fbb97ce4 0%, #ff00006a 100%);
      --dark-bg: linear-gradient(135deg, #fbb97ce4 0%, #ff00006a 100%);
      --card-shadow: 0 15px 35px rgba(0,0,0,.1);
      --hover-shadow: 0 25px 50px rgba(0,0,0,.15);
      --border-radius: 20px;
      --transition: all .3s cubic-bezier(.4,0,.2,1);
    }
    * { transition: var(--transition); }
    body {
      background: linear-gradient(135deg, #ffffff 0%, #ffffff 100%);
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      min-height: 100vh;
    }
    .sb-topnav {
      background: var(--dark-bg) !important;
      border: none;
      box-shadow: var(--card-shadow);
      backdrop-filter: blur(10px);
    }
    .navbar-brand {
      font-weight: 700;
      font-size: 1.5rem;
      background: linear-gradient(45deg, #ffffff, #ffffff);
      background-clip: text;
      -webkit-background-clip: text;
      color: transparent;
      -webkit-text-fill-color: transparent;
      text-shadow: none;
    }
    .sb-sidenav {
      background: linear-gradient(180deg, #fbb97ce4 0%, #ff00006a 100%) !important;
      box-shadow: var(--card-shadow);
      backdrop-filter: blur(10px);
    }
    .sb-sidenav-menu-heading {
      color: rgba(255,255,255,.7) !important;
      font-weight: 600;
      font-size: .85rem;
      text-transform: uppercase;
      letter-spacing: 1px;
      padding: 20px 15px 10px 15px !important;
      margin-top: 15px;
    }
    .sb-sidenav .nav-link {
      border-radius: 15px;
      margin: 5px 15px;
      padding: 12px 15px;
      position: relative;
      overflow: hidden;
      color: rgba(255,255,255,.9) !important;
      font-weight: 500;
      backdrop-filter: blur(10px);
    }
    .sb-sidenav .nav-link:hover {
      background: rgba(255,255,255,.15) !important;
      transform: translateX(8px);
      box-shadow: 0 8px 25px rgba(0,0,0,.2);
      color: #fff !important;
    }
    .sb-sidenav .nav-link.active {
      background: rgba(255,255,255,.2) !important;
      color: #fff !important;
      font-weight: 600;
      box-shadow: 0 8px 25px rgba(0,0,0,.15);
    }
    .sb-sidenav .nav-link::before {
      content: '';
      position: absolute; left: 0; top: 0; height: 100%; width: 4px;
      background: linear-gradient(45deg, #ffffff, #ffffff);
      transform: scaleY(0);
      transition: var(--transition);
      border-radius: 0 10px 10px 0;
    }
    .sb-sidenav .nav-link:hover::before,
    .sb-sidenav .nav-link.active::before { transform: scaleY(1); }
    .sb-sidenav .nav-link i { width: 20px; text-align: center; margin-right: 10px; font-size: 1rem; }
    .sb-sidenav-footer {
      background: rgba(255,255,255,.1) !important;
      color: #fff !important;
      border-top: 1px solid rgba(255,255,255,.2);
      padding: 20px 15px;
      margin-top: 20px;
    }
    .container-fluid { padding: 30px !important; }
    h1 {
      background: var(--primary-gradient);
      background-clip: text;
      -webkit-background-clip: text;
      color: transparent;
      -webkit-text-fill-color: transparent;
      font-weight: 700;
      font-size: 2.5rem;
      margin-bottom: 30px;
    }
    .breadcrumb {
      background: rgba(255,255,255,.8);
      border-radius: var(--border-radius);
      padding: 15px 20px;
      box-shadow: var(--card-shadow);
      backdrop-filter: blur(10px);
    }
    .table {
      border-radius: var(--border-radius);
      overflow: hidden;
      background: #fff;
      box-shadow: var(--card-shadow);
    }
    .table thead th {
      background: var(--primary-gradient);
      color: #000;
      border: none;
      font-weight: 600;
      padding: 15px;
    }
    .table tbody td {
      padding: 15px;
      vertical-align: middle;
      border-color: rgba(0,0,0,.05);
    }
    .table tbody tr:hover {
      background: rgba(227, 23, 111, 0.05);
      transform: scale(1.01);
    }
    .sb-topnav .form-control {
      border-radius: 25px;
      border: 2px solid transparent;
      background: rgba(255,255,255,.2);
      color: #fff;
    }
    .sb-topnav .form-control:focus {
      background: rgba(255,255,255,.3);
      border-color: rgba(255,255,255,.5);
      box-shadow: 0 0 20px rgba(255,255,255,.2);
      color: #fff;
    }
    .btn-primary {
      background: var(--primary-gradient);
      border: none;
      border-radius: 25px;
    }
    .btn-primary:hover {
      transform: scale(1.05);
      box-shadow: 0 10px 25px rgba(209, 209, 209, 0.976);
    }
  </style>
</head>

<body class="sb-nav-fixed">
  <nav class="sb-topnav navbar navbar-expand navbar-dark bg-dark">
    <a class="navbar-brand ps-3" href="index.php">員工管理系統</a>
    <button class="btn btn-link btn-sm order-1 order-lg-0 me-4 me-lg-0" id="sidebarToggle" type="button">
      <i class="fas fa-bars"></i>
    </button>

    <form class="d-none d-md-inline-block form-inline ms-auto me-0 me-md-3 my-2 my-md-0">
      <div class="input-group">
        <input class="form-control" type="text" placeholder="Search for..." aria-label="Search" />
        <button class="btn btn-primary" id="btnNavbarSearch" type="button"><i class="fas fa-search"></i></button>
      </div>
    </form>

    <ul class="navbar-nav ms-auto ms-md-0 me-3 me-lg-4">
      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" id="navbarDropdown" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
          <i class="fas fa-user fa-fw"></i>
        </a>
        <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
          <li><a class="dropdown-item" href="設定.php">Settings</a></li>
          <li><a class="dropdown-item" href="活動紀錄.php">Activity Log</a></li>
          <li><hr class="dropdown-divider" /></li>
          <li><a class="dropdown-item" href="<?= htmlspecialchars($API_BASE_URL) ?>/logout.php">Logout</a></li>
        </ul>
      </li>
    </ul>
  </nav>

  <div id="layoutSidenav">
    <div id="layoutSidenav_nav">
      <nav class="sb-sidenav accordion sb-sidenav-dark" id="sidenavAccordion">
        <div class="sb-sidenav-menu">
          <div class="nav">
            <div class="sb-sidenav-menu-heading">Core</div>
            <a class="nav-link" href="index.php">
              <div class="sb-nav-link-icon"><i class="fas fa-tachometer-alt"></i></div>首頁
            </a>

            <div class="sb-sidenav-menu-heading">Pages</div>
            <a class="nav-link collapsed" href="#" data-bs-toggle="collapse" data-bs-target="#collapseLayouts" aria-expanded="false">
              <div class="sb-nav-link-icon"><i class="fas fa-columns"></i></div>人事管理
              <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
            </a>
            <div class="collapse" id="collapseLayouts" data-bs-parent="#sidenavAccordion">
              <nav class="sb-sidenav-menu-nested nav">
                <a class="nav-link" href="員工資料表.php">員工資料表</a>
                <a class="nav-link" href="班表管理.php">班表管理</a>
                <a class="nav-link" href="日報表記錄.php">日報表記錄</a>
                <a class="nav-link active" href="假別管理.php">假別管理</a>
                <a class="nav-link" href="打卡記錄.php">打卡紀錄</a>
                <a class="nav-link" href="薪資管理.php">薪資管理</a>
              </nav>
            </div>

            <a class="nav-link collapsed" href="#" data-bs-toggle="collapse" data-bs-target="#collapseOperation" aria-expanded="false">
              <div class="sb-nav-link-icon"><i class="fas fa-chart-line"></i></div>營運管理
              <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
            </a>
            <div class="collapse" id="collapseOperation" data-bs-parent="#sidenavAccordion">
              <nav class="sb-sidenav-menu-nested nav accordion" id="sidenavAccordionOperation">
                <a class="nav-link collapsed" href="#" data-bs-toggle="collapse" data-bs-target="#operationCollapseInventory" aria-expanded="false">
                  庫存管理
                  <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                </a>
                <div class="collapse" id="operationCollapseInventory" data-bs-parent="#sidenavAccordionOperation">
                  <nav class="sb-sidenav-menu-nested nav">
                    <a class="nav-link" href="庫存查詢.php">庫存查詢</a>
                    <a class="nav-link" href="庫存調整.php">庫存調整</a>
                  </nav>
                </div>

                <a class="nav-link" href="日報表.php"><div class="sb-nav-link-icon"></div>日報表</a>
                <a class="nav-link" href="薪資記錄.php"><div class="sb-nav-link-icon"></div>薪資記錄</a>
                <a class="nav-link" href="班表.php"><div class="sb-nav-link-icon"></div>班表</a>
              </nav>
            </div>

            <a class="nav-link" href="請假申請.php"><div class="sb-nav-link-icon"><i class="fas fa-calendar-alt"></i></div>請假申請</a>

            <a class="nav-link collapsed" href="#" data-bs-toggle="collapse" data-bs-target="#collapseWebsite" aria-expanded="false">
              <div class="sb-nav-link-icon"><i class="fas fa-cogs"></i></div>網站管理
              <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
            </a>
            <div class="collapse" id="collapseWebsite" data-bs-parent="#sidenavAccordion">
              <nav class="sb-sidenav-menu-nested nav accordion" id="sidenavAccordionWebsite">
                <a class="nav-link" href="layout-static.php">官網資料修改</a>
                <a class="nav-link collapsed" href="#" data-bs-toggle="collapse" data-bs-target="#websiteCollapseMember" aria-expanded="false">
                  會員管理
                  <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                </a>
                <div class="collapse" id="websiteCollapseMember" data-bs-parent="#sidenavAccordionWebsite">
                  <nav class="sb-sidenav-menu-nested nav">
                    <a class="nav-link" href="member-list.php">會員清單</a>
                    <a class="nav-link" href="member-detail.php">詳細資料頁</a>
                    <a class="nav-link" href="point-manage.php">點數管理</a>
                  </nav>
                </div>
              </nav>
            </div>

            <div class="sb-sidenav-menu-heading">Addons</div>
            <a class="nav-link" href="charts.php"><div class="sb-nav-link-icon"><i class="fas fa-chart-area"></i></div>Charts</a>
            <a class="nav-link" href="tables.php"><div class="sb-nav-link-icon"><i class="fas fa-table"></i></div>Tables</a>
          </div>
        </div>

        <div class="sb-sidenav-footer">
          <div class="small">Logged in as:</div>
          Start Bootstrap
        </div>
      </nav>
    </div>

    <div id="layoutSidenav_content">
      <main>
        <div class="container-fluid px-4">
          <div class="d-flex justify-content-between align-items-center mb-3">
            <h1>假別管理</h1>
            <div class="text-muted"><i class="fas fa-calendar-alt me-2"></i><span id="currentDate"></span></div>
          </div>

          <ol class="breadcrumb mb-4">
            <li class="breadcrumb-item"><a href="index.php" class="text-decoration-none">首頁</a></li>
            <li class="breadcrumb-item active">假別管理</li>
          </ol>

          <div id="errorAlert" class="alert alert-danger d-none" role="alert">
            <i class="fas fa-exclamation-triangle me-2"></i>
            <span id="errorMessage"></span>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
          </div>
          <div id="successAlert" class="alert alert-success d-none" role="alert">
            <i class="fas fa-check-circle me-2"></i>
            <span id="successMessage"></span>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
          </div>

          <div class="card p-3 mb-4">
            <div class="card-header"><i class="fas fa-list me-2"></i>員工請假紀錄</div>
            <div class="card-body">
              <div class="table-responsive">
                <table class="table table-bordered table-hover text-center align-middle">
                  <thead>
                    <tr>
                      <th>員工</th>
                      <th>假別</th>
                      <th>開始</th>
                      <th>結束</th>
                      <th>原因</th>
                      <th>狀態</th>
                    </tr>
                  </thead>
                  <tbody id="allLeaveTable">
                    <tr><td colspan="6" class="text-muted">載入中…</td></tr>
                  </tbody>
                </table>
              </div>
            </div>
          </div>

          <div class="card p-3">
            <div class="card-header"><i class="fas fa-clipboard-check me-2"></i>請假審核管理</div>
            <div class="card-body">
              <div class="table-responsive">
                <table class="table table-bordered table-hover text-center align-middle">
                  <thead>
                    <tr>
                      <th>員工</th>
                      <th>假別</th>
                      <th>開始</th>
                      <th>結束</th>
                      <th>原因</th>
                      <th>照片</th>
                      <th>狀態</th>
                      <th>操作</th>
                    </tr>
                  </thead>
                  <tbody id="leaveReviewTable">
                    <tr><td colspan="8" class="text-muted">載入中…</td></tr>
                  </tbody>
                </table>
              </div>
            </div>
          </div>

        </div>
      </main>

      <footer class="py-4 bg-light mt-auto">
        <div class="container-fluid px-4">
          <div class="d-flex align-items-center justify-content-between small">
            <div class="text-muted">Copyright &copy; Xxing0625</div>
            <div>
              <a href="#">Privacy Policy</a> &middot; <a href="#">Terms &amp; Conditions</a>
            </div>
          </div>
        </div>
      </footer>
    </div>
  </div>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
  <script>
    // 後端路徑（從 PHP 注入）
    const API_BASE_URL   = <?= json_encode($API_BASE_URL) ?>;
    const DATA_BASE_URL  = <?= json_encode($DATA_BASE_URL) ?>;
    const LEAVE_BASE_URL = <?= json_encode($LEAVE_BASE_URL) ?>;

    // 日期顯示與側欄收合
    document.getElementById('currentDate').textContent =
      new Date().toLocaleDateString('zh-TW',{year:'numeric',month:'long',day:'numeric',weekday:'long'});
    document.getElementById('sidebarToggle').addEventListener('click', e=>{
      e.preventDefault(); document.body.classList.toggle('sb-sidenav-toggled');
    });

    // 提示函數
    function showError(msg){
      const a = document.getElementById('errorAlert');
      document.getElementById('errorMessage').textContent = msg;
      a.classList.remove('d-none');
      setTimeout(() => a.classList.add('d-none'), 5000);
    }
    function showSuccess(msg){
      const a = document.getElementById('successAlert');
      document.getElementById('successMessage').textContent = msg;
      a.classList.remove('d-none');
      setTimeout(() => a.classList.add('d-none'), 3000);
    }

    // 狀態徽章
    function statusBadge(s){
      const status = parseInt(s);
      if(status === 2) return `<span class="badge bg-success">已通過</span>`;
      if(status === 3) return `<span class="badge bg-danger">已駁回</span>`;
      return `<span class="badge bg-warning text-dark">未審核</span>`;
    }

    // 取得員工請假紀錄
    async function loadAllLeave(){
      const tbody = document.getElementById('allLeaveTable');
      try{
        const res = await fetch(`${LEAVE_BASE_URL}/取得請假紀錄.php`, { credentials: 'include' });
        if(!res.ok) throw new Error(res.status + ' ' + res.statusText);
        const data = await res.json();
        tbody.innerHTML = (data || []).map(item => `
          <tr>
            <td>${item.employee ?? ''}</td>
            <td>${item.type ?? ''}</td>
            <td>${item.start ?? ''}</td>
            <td>${item.end ?? ''}</td>
            <td class="text-start">${item.reason ?? ''}</td>
            <td>${statusBadge(item.status)}</td>
          </tr>`).join('') || `<tr><td colspan="6" class="text-muted">目前沒有資料</td></tr>`;
      }catch(e){
        console.warn(e);
        tbody.innerHTML = `<tr><td colspan="6" class="text-danger">載入失敗</td></tr>`;
        showError('無法載入員工請假紀錄');
      }
    }

    // 取得審核列表
    async function loadLeaveReview(){
      const tbody = document.getElementById('leaveReviewTable');
      try{
        const res = await fetch(`${LEAVE_BASE_URL}/取得審核列表.php`, { credentials: 'include' });
        if(!res.ok) throw new Error(res.status + ' ' + res.statusText);
        const data = await res.json();
        tbody.innerHTML = (data || []).map(item => `
          <tr>
            <td>${item.employee ?? ''}</td>
            <td>${item.type ?? ''}</td>
            <td>${item.start ?? ''}</td>
            <td>${item.end ?? ''}</td>
            <td class="text-start">${item.reason ?? ''}</td>
            <td>${item.photo ? `<a href="${item.photo}" target="_blank">查看</a>` : '無'}</td>
            <td>${statusBadge(item.status)}</td>
            <td>
              <button class="btn btn-success btn-sm me-1" onclick="confirmReview(${item.id}, 'approve')"><i class="fas fa-check"></i> 通過</button>
              <button class="btn btn-danger btn-sm" onclick="confirmReview(${item.id}, 'reject')"><i class="fas fa-times"></i> 駁回</button>
            </td>
          </tr>`).join('') || `<tr><td colspan="8" class="text-muted">目前沒有待審核項目</td></tr>`;
      }catch(e){
        console.warn(e);
        tbody.innerHTML = `<tr><td colspan="8" class="text-danger">載入失敗</td></tr>`;
        showError('無法載入審核列表');
      }
    }

    // 審核確認
    function confirmReview(id, action){
      const message = action === 'approve' ? '確定通過這筆請假嗎？' : '確定駁回這筆請假嗎？';
      if(confirm(message)) reviewLeave(id, action);
    }

    // 送審核 API
    async function reviewLeave(id, action){
      try{
        const res = await fetch(`${LEAVE_BASE_URL}/review_leave.php`, {
          method: 'POST',
          headers: {'Content-Type': 'application/json'},
          credentials: 'include',
          body: JSON.stringify({ leaveId: id, action })
        });

        const text = await res.text();
        if(!res.ok){
          try{
            const err = JSON.parse(text);
            showError(err.error || '審核操作失敗');
          }catch{
            showError('審核操作失敗: ' + text);
          }
          return;
        }

        try{
          const result = JSON.parse(text);
          let msg = result.message || '操作成功';
          if(result.emailSent === false){
            msg += ' ⚠️ (Email 通知發送失敗: ' + (result.emailMessage || '未知錯誤') + ')';
          }else if(result.emailSent === true){
            msg += ' ✅ (已發送通知信)';
          }
          showSuccess(msg);
        }catch{
          showSuccess(text || '操作成功');
        }

        await Promise.all([loadLeaveReview(), loadAllLeave()]);
      }catch(e){
        console.error(e);
        showError('審核操作失敗: ' + e.message);
      }
    }

    // 初始化
    window.addEventListener('DOMContentLoaded', () => {
      loadAllLeave();
      loadLeaveReview();
    });
  </script>
  <script src="js/scripts.js"></script>
</body>
</html>
