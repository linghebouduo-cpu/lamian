<?php
session_start();
header('Content-Type: application/json; charset=utf-8');

// --- 資料庫設定 ---
$host = 'localhost';
$db   = 'lamian';
$user = 'root';
$pass = ''; // XAMPP 預設
$charset = 'utf8mb4';

// --- 建立連線 ---
$dsn = "mysql:host=$host;dbname=$db;charset=$charset";
$options = [
    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
];
try {
    $pdo = new PDO($dsn, $user, $pass, $options);
} catch (PDOException $e) {
    echo json_encode(['error' => '資料庫連線失敗']);
    exit;
}

// --- 接收登入資料 ---
$data = json_decode(file_get_contents('php://input'), true);
if (!$data || !isset($data['account'], $data['password'])) {
    echo json_encode(['error' => '缺少帳號或密碼']);
    exit;
}

$account = trim($data['account']);
$password = $data['password'];

// --- 查詢帳號 ---
$stmt = $pdo->prepare("SELECT id, name, account, password_hash FROM `員工基本資料` WHERE account = ?");
$stmt->execute([$account]);
$user = $stmt->fetch();

if (!$user) {
    echo json_encode(['error' => '帳號不存在']);
    exit;
}

// --- 比對密碼（目前是明文，日後可改成 password_verify）---
if ($password !== $user['password_hash']) {
    echo json_encode(['error' => '密碼錯誤']);
    exit;
}

// --- 登入成功：建立 Session ---
$_SESSION['user_id'] = $user['id'];
$_SESSION['user_name'] = $user['name'];
$_SESSION['user_account'] = $user['account'];

echo json_encode(['ok' => true, 'message' => '登入成功']);
