<?php
// /lamian-ukn/api/config.php

// === DB 連線設定 (lamian 資料庫 - 主要業務) ===
const DB_HOST = '127.0.0.1';
const DB_NAME = 'lamian';
const DB_USER = 'root';   // <--- 請確認這是正確的使用者
const DB_PASS = '';       // <--- 請確認這是正確的密碼

// === 員工表 與 打卡表 ===
const EMP_TABLE     = '員工資料';
const EMP_PK_COL    = 'id';
const EMP_NAME_COL  = 'name';
const EMP_CODE_COL  = 'id'; // 打卡輸入代碼
const ATT_TABLE     = 'attendance';

// === 密碼重設設定 ===
const RESET_CODE_TTL_MIN = 10; // 驗證碼有效時間 (分鐘)
const RESET_MAX_ATTEMPTS = 5;  // 驗證碼最大嘗試次數

// === 郵件 (SMTP) 設定 (參考您同學的 Gmail 設定) ===
// ** 請務必修改為您真實的 Gmail 帳號和應用程式密碼 **
const SMTP_HOST     = 'smtp.gmail.com';
const SMTP_PORT     = 587;
const SMTP_USERNAME = 'linghebouduo@gmail.com'; // <--- 您的 Gmail 帳號
const SMTP_PASSWORD = 'jrgp lxxq dcea vuxn';    // <--- 您的 Gmail 應用程式密碼
const SMTP_SECURE   = 'tls';                    // PHPMailer::ENCRYPTION_STARTTLS
const MAIL_FROM_EMAIL = 'linghebouduo@gmail.com'; // <--- 您的 Gmail 帳號 (寄件者)
const MAIL_FROM_NAME  = '拉麵店員工管理系統';     // <--- 寄件者名稱

// === 共用 PDO 連線函數 (lamian 資料庫) ===
function pdo(){
  static $pdo = null;
  if ($pdo) return $pdo;
  $dsn = 'mysql:host='.DB_HOST.';dbname='.DB_NAME.';charset=utf8mb4';
  try {
      $pdo = new PDO($dsn, DB_USER, DB_PASS, [
          PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
          PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
          PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8mb4",
      ]);
  } catch (PDOException $e) {
      error_log("PDO Connection Error (lamian): " . $e->getMessage());
      err('資料庫連線失敗', 500);
  }
  return $pdo;
}

// === 共用 JSON 回應函數 ===
function ok($data){
  // 確保在輸出 JSON 前沒有其他輸出
  if (!headers_sent()) {
      header('Content-Type: application/json; charset=utf-8');
  }
  echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_NUMERIC_CHECK);
  exit;
}

function err($msg, $code = 400, $ext = []){
  // 確保在輸出 JSON 前沒有其他輸出
  if (!headers_sent()) {
      header('Content-Type: application/json; charset=utf-8');
      http_response_code($code);
  }
  echo json_encode(['error'=>$msg] + $ext, JSON_UNESCAPED_UNICODE);
  exit;
}


function g($k,$d=null){ return isset($_GET[$k]) ? trim((string)$_GET[$k]) : $d; }

// === 載入 PHPMailer ===
// 假設 vendor 目錄在 api 的上一層 (/lamian-ukn/vendor)
//require_once __DIR__ . '/../vendor/autoload.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
use PHPMailer\PHPMailer\SMTP; // 需要 use SMTP

/**
 * 使用 PHPMailer 發送郵件的通用函數 (參考您同學的設定)
 * @param string $to 收件者 Email
 * @param string $toName 收件者名稱 (可選)
 * @param string $subject 主旨
 * @param string $htmlBody HTML 內容
 * @param string $altBody 純文字內容 (可選)
 * @return bool 是否成功
 */
function send_email(string $to, string $toName, string $subject, string $htmlBody, string $altBody = ''): bool {
    $mail = new PHPMailer(true);
    try {
        //伺服器設定
        $mail->SMTPDebug = SMTP::DEBUG_SERVER; // **** 開啟詳細除錯輸出 ****
        $mail->isSMTP();
        $mail->Host       = SMTP_HOST;
        $mail->SMTPAuth   = true;
        $mail->Username   = SMTP_USERNAME;
        $mail->Password   = SMTP_PASSWORD;
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port       = SMTP_PORT;
        $mail->CharSet    = PHPMailer::CHARSET_UTF8;

        //寄件者
        $mail->setFrom(MAIL_FROM_EMAIL, MAIL_FROM_NAME);

        //收件者
        $mail->addAddress($to, $toName);

        //內容
        $mail->isHTML(true);
        $mail->Subject = $subject;
        $mail->Body    = $htmlBody;
        $mail->AltBody = ($altBody === '') ? strip_tags($htmlBody) : $altBody;

        $mail->send();
        // 如果除錯模式開啟，成功發送後可能也會輸出信息，所以這裡不直接 return true
        // echo "Message has been sent\n"; // 可以在這裡加個標記，確認執行到這
        return true;
    } catch (Exception $e) {
        // 記錄詳細錯誤到伺服器日誌
        error_log("PHPMailer Error sending to {$to}: {$mail->ErrorInfo}");
        // 如果除錯模式開啟，錯誤信息會直接輸出，這裡 return false
        return false;
    }
}
?>